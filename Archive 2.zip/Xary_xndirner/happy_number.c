#include <stdio.h>
#include <stdbool.h>



bool isHappy(int n) {
    int org_n = n;
    int res = 0;
    int mn = 0;
    while(n != 1){
        res = 0;
        while(n > 0){
            mn = n % 10;
            res += (mn * mn);
            n /= 10;
        }
        if(res == 4){return false;}
        n = res;
    }
    return true;
}

int main(){
 
    int x;
    scanf("%d",&x);
    printf("%d",isHappy(x));
}