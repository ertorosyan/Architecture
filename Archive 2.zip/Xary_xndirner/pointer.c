#include <stdio.h>
//xntir 2 tpi ekranin zangvaci elementnery 

void array_print(int *arr,int size){
	int *el = &arr[0];
	for(int i = 0; i< size ; i++){
		printf("%d ",*el);  //kam *(el + 1)
		++ *el;
	}
}
// xndir 4 cucichi mijocov matematikakakn gorcoxutyunner
void calculator(int* px, int* py){
	printf("x + y == %d\n",*px + *py);
	printf("x - y == %d\n",*px - *py);
	printf("x * y == %d\n",*px * *py);
	printf("x / y == %d\n",*px / *py);
}

 // xndir 5 swap ani cucichi mijocow

void swap(int *px , int*py){
	int tmp = *px;
	*px = *py;
	*py = tmp;
	printf(" x = %d\n y = %d\n", *px ,*py); 
}
int main(){

int arr[] ={1,2,3,4,5};
int size = sizeof(arr)/sizeof(int);
//int *el = &arr[0];
//array_print(arr,size);

//xntir 4
int x = 10;
int y = 5;
int *px = &x;
int *py = &y;
//calculator(px,py);
swap(px,py);


//xndir1 haytarari tarber type-ri popoxakaner  u tpi ekranin cucichi mijocow

/*
int x  = 10;
char ch = 20;
double db = 30;

int* px = &x;
char* pch = &ch;
double* dob = &db;

printf("int x = %d\n",*px);
printf("char ch = %d\n",*pch);
printf("double  = %f\n",*dob);
*/



}
