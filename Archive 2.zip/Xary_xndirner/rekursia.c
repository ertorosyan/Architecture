#include <stdio.h>


// stana tiv u veradzrcni tvayerord tivy yst fibonachiyi tveri;
	int a = 0,  b = 1, element;
	for(int i = 2; i <= 1 ; i++){
		element = a + b;
		a = b;
		b = element;
	}
	return (x < 0) ? b : a;

// GTNEL factorialy REKURSIV function-ov
	if(x == 1 || x == 0)
		return 1;
	return x * fib(x-1); 

// Stana tiv u tpi et tvic minchew 0-n;

if(x == 0)
	return 0;
printf("%d",x);
return fib(x-1);

//stana zangvac u chap, tpi hakarak dasavorvacutyamb

void zangvac(int *arr, int size){
	
	if(size == 0)
		return;
	printf("%d ",arr[size-1]);
	return zangvac(arr,size-1);
		
}

// stana zangvac u chp, tpi ekranin

void zangvac(int *arr,int size){
	if(size == 0)
		return ;
	printf("%d ",arr[0]);
	return zangvac(arr + 1,size - 1);
}



int expon(int tiv,int exp){
	if(exp == 0 )
		return tiv;
	
	return expon( tiv*tiv , exp - 1);
}

int main(){
	
	int tiv = 3, exp = 3;
	printf("% d",expon(tiv,exp)) ;
}

