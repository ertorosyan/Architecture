#include <stdio.h>


int swap_bit(int num , int i , int j){
	
	if((( num >> i ) & 1)  != ((num >> j) & 1))
		num = num ^ ((1 << i ) | ( 1 << j));
	
	return num;
}

	// 1000
	// 0001

int main(){

	int num = 16;
	int i = 1;
	int j = 4;

	printf("%d" , swap_bit(16,i,j));
}
