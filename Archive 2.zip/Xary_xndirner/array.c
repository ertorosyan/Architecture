#include <stdio.h>
int main(){
	int row = 4;
	int column = 4;

	int arr[][4]={  {7,2,3,4},
					{1,7,3,4},
					{1,2,7,4},
					{1,2,3,7}};
	int size = sizeof(arr)/sizeof(arr[0]);	

printf("size = %d",size);
// tpi matricy
	for(int i = 0 ; i < size ; i++ ){
		printf("\n");
		for(int j = 0 ; j < size ; j++){
			printf(" %d ",arr[i][j]);
		}
	}
//tpi ankyunagci 

int tmp = 0;
	for(int i = 0 ; i < size ; i++){
		//for(int j = 0 ; j < size ; j++){
			
			tmp = arr[i][i]	;
			arr[i][i] = arr[i][row-1-i];
			arr[i][row-1-i]=tmp;

		//}
	}
	for(int i = 0; i < size ; i++){
		printf("\n");
		for(int j = 0; j < size ; j++){
			printf("%d",arr[i][j]);
		}
	}
}
