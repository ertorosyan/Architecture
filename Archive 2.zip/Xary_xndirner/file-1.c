#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

// bool isHappy(int n) {
//     int res ;
//     int mnacort;
//     int interacia;
//     while(n && interacia < 1000){
//         if(n == 1){return true;}
//         res = 0;
//         while(n > 0 ){
//             mnacort = n % 10;
//             res += (mnacort * mnacort);
//             n /= 10;
//         }
//         n = res;
//         interacia++;
//     }
//     return false;
// }



bool isIsomorphic(char* s, char* t) {
    int* str = (int*)calloc(20,sizeof(int));
    int* str2 = (int*)calloc(20,sizeof(int));

    // char* s //
    int size = strlen(s);
    int k = 0;
    for(int i = 0 ; i < strlen(s) ; ++i){
        int j = size;
        for(; j >= i ; --j){
            if(s[i] == s[j]){
                str[k] = j;
                printf("str = %d \n",str[k]);
                k++;
            }
        }
        size--;
    }

    // char* t //
    size = strlen(t);
    k = 0;
    for(int i = 0 ; i < strlen(s) ; ++i){
        int j = size;
        for(; j >= i ; --j){
            if(t[i] == t[j]){
                str2[k] = j;
                printf("str2 = %d \n",str2[k]);
                k++;
            }
        }
        size--;
    }
    int res = 1;
    for(int i = 0 ; i < 20 ;++i){
        if(str[i] != str2[i])
            res = 0;
    }   


    // for(int i = 0 ; i < 20 ; ++i)
    //     printf("%d ",str2[i]);

    free(str);
    free(str2);
    if(res == 1){return true;}
    return false;
}
int main(){
    char* s = "aba";
    char* t = "aba";
    printf("\n%d\n",isIsomorphic(s,t));
}