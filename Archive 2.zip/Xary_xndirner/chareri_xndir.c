#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <stdbool.h>




double charToDouble(char* ptr, int i, int j) {
	double res = 0;
	double k = 10;
	bool t = false;
	while(i <= j) {
		if (ptr[i] == '.') {
			t = true;
		} else {
			if (t) {
				res += (ptr[i] - '0') / k;	
				k *= 10;			
			} else {
				res = res * 10 + ptr[i] - '0';
			}
		}
		i++;
	}

	return res;

}


double calc(char* s) {
	int i = 0;
	int j = 0;
	double result = 0;
	double tmp = 0;
	char operation = '+';
	while(s[i]){
		if(s[i] == ' ') {
			i++;
			j++;
		} else if(s[i] >= '0' && s[i] <= '9' || s[i] == '.') {
			i++;
			if((s[i] <= '0' || s[i] >= '9') && s[i] != '.') {
				tmp = charToDouble(s, j, i - 1);
				if (operation == '+') {
					result += tmp;
				}
				else if (operation == '-') {
					result -= tmp;
				}
			    j = i;
				while(s[i] == ' ') {i++; j++;}
				if(s[i] == '+') { 
					operation = '+';
					i++;
					j++;
				} else if(s[i] == '-'){
					operation = '-';
					i++;
					j++;
				}
			}
		}
	}
	return result;
}


int main(){

    char* str = " 10 + 5.5 - 2";
    double res = calc(str);
    printf("%lf",res);
    //printf("%lf" , CharToDouble("15.5555",0, strlen("15.5555")));
}