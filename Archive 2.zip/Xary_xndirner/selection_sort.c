#include <stdio.h>


void swap(int* x, int* y){
	int tmp = *x;
	*x = *y;
	*y = tmp;
}

void selection_sort(int* arr,int size){

	for(int i = 0 ; i < size-1 ; ++i){     // 2 3 4 1 0
		int min = i;
		for(int j = i+1 ; j < size ; ++j ){
			if(arr[min] >  arr[j])
				swap(&arr[min],&arr[j]);
		}
	}

}
// -2 2 4 -1 5 0 
	


int main(){

	int arr[] = {-2,2,4,-1,5,0};
	selection_sort(arr,6);
	for(int i = 0 ; i < 6 ; ++i){
		printf("%d ",arr[i]);
	}


}
