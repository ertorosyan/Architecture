#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

bool isIsomorphic(char* s, char* t) {
    if(s == NULL || t == NULL){return false;}
    if(strcmp(s,t) < 0){return false;}

    char str[20] = {'0'};
    char str1[256] = {'0'};
    for(int i = 0 ; s[i+1]  ;++i ){
        for(int j = i + 1 ; s[j] ; ++j){
            printf("s[i] = %c\n",s[i]);
            if(s[i] == s[j]){
                str[i] = '1';
                str[j] = '1';
            }else{
                str[j] = '0';
                str[i] = '0';
            }
        }
    }
    for(int i = 0 ; t[i+1]  ;++i ){
        for(int j = i+1 ; t[j] ; ++j){
            if(t[i] == t[j]){
                str1[j] = '1';
                str1[i] = '1';
            }else{
                str1[j] = '0';
                str1[i] = '0';
            }
        }
    }
    printf("%s\n",str);
    printf("%s\n",str1);
    if(strcmp(str,str1) == 0){return true;}


    return false;
}

int main(){
    char* s = "leeat";
    char* t = "ceeat";
    printf("\n%d\n",isIsomorphic(s,t));
}