#include <stdio.h>

float sum(float x , float y){
	return x + y;
}

float sub(float x , float y){
	return x * y;
}

float mull(float x , float y){
	return x * y;
}


float hashvich(float x , float y , float(*ptr)(float,float)){

	if(ptr(x,y))
		return ptr(x,y);
	return 0;
}
void swap(int* x , int* y){
	int tmp = *x;
	*x = *y;
	*y = tmp;
}

void swap_mat(int arr[][3] , int row , int col){
	
	for(int i = 0 ; i < row ; ++i ){
		for(int j = 0 ; j < col ; ++j){
			if(j > i)
				swap(&arr[i][j] , &arr[j][i]);
		}
	}
	
}

int main(){

	int matrix[][3] = {{1,2,3},
						{4,5,6},
						{7,8,9}};
	int row = 3;
	int col = 3;
	
	swap_mat(matrix , row,col);


	for(int i = 0 ; i < row ; ++i ){
		printf("\n");
		for(int j = 0 ; j < col ; ++j){
			printf("%d " , matrix[i][j]);
		}
	}


	int x = 10;
	int y = 5;
	//	float (*arr[])(float,float) = {sum ,sub ,mull};
	
	//for (int i = 0 ; i  < 3 ; ++i){
	//	printf(" %f\n" ,hashvich(x,y,arr[i]));
	//}

}
