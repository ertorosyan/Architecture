#include <stdio.h>

void swap(int* x,int* y){
	int tmp = *x;
	*x = *y;
	*y = tmp;
}

void insertion_sort(int* arr,int size){
	for(int i = 1 ; i < size; ++i){  //    6 5 3 1 8
		int j = i; 
		while( j > 0)
		{
			if(arr[j - 1] > arr[j])
				swap(&arr[j-1],&arr[j]);
			--j;
		}
	}
}



int main(){
	int arr[] = {-1,-2,4,65,8,6};
	int size = sizeof(arr)/sizeof(int);
	insertion_sort(arr,size);
	for(int i = 0 ; i < size ; ++i){
		printf("%d ",arr[i]);
	}
}
