#include <stdio.h>
int revers_bit(unsigned char num ){
	
	unsigned char original = 0;;
	char i = 1;							
	while(num != 0){
		if((num & 1) == 1){
			original |= (1 << (8 - i));
		}
		num = num >> 1;
		++i; 	
	}
	return original;
}
				
int main(){
	unsigned char x  = 3;
	printf(" skzbnakan tivy = %d\n",x);
	printf(" verjnakan tivy = %d\n", revers_bit(x) );
}
