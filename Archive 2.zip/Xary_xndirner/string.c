#include <stdio.h>
#include <string.h>

/*
// memcpy()  function

void *memorymcpy(void *dest, const void *src, size_t n){
	for(int i = 0 ; i < n ; i++){
		((unsigned char *)dest)[i] = ((unsigned char *)src)[i];
	}
	printf("%s\n",(unsigned char *)dest);
	return dest;
}

// strcat function
	
char *strcatt(char *dest, const char *src){
	int i = 0;
	while(dest[i] != '\0'){
		i++;
	}
	for(int j = 0 ;src[j] != '\0' ;j++ , i++){
		dest[i] = src[j];
	}
	
	printf("%s\n",dest);
	return dest;
}


// strlen() function

size_t strlenn(const char *s1){
	int count = 0;
	for (int i = 0 ; s1[i] != '\0' ; i++){
		count++;
	}
	return count;
}

// strchr() function
char *strchrr(const char *str, char character){
	for(int i = 0; str[i] != '\0' ; i++){
		if(str[i] == character)
			return ((char*)str + i);		
	}
	return NULL;
}
*/
 // strcmp function 
char strcmpp(char *str1,char * str2){
	for(int i = 0 ; str1[i] != '\0' && str2[i] != '\0' && str1[i] == str2[i] ; i++){

		if(str1[i + 1] != str2[i + 1])
			return str1[i + 1] - str2[i + 1];

		if(str1[i+1] == '\0' || str2[i+1] == '\0')
			return (str1[i+1] - str2[i+1]) ;				
	}
	return 0;
}

int main() {
	//char dest[] = "Hellow ";
     char str1[] = "WorldI";
     char str2[] = "World";
	//char character = 'o';
	//printf("Size = %zu",strlenn(s1));
	printf("%c", strcmpp(str1,str2));
	//strcatt(dest,src);
	//size_t n = strlen(src);
	//memorymcpy(dest,src,5);
}


