#include <stdio.h>
int main(){

int  num, sum = 0,x ,end,fac = 1,i ,j ;

scanf(" %d",&end);

	
for(int j = 1 ; j <= end ; j++)
	{ 	
		i = j;
		sum = 0;
		while(i != 0)
		{
			num = i % 10;	
			fac = 1;
				for (int f = 1 ; f <= num ; f++)
					{
						fac *= f ; 
					}
			sum += fac;
			i /= 10;
		}

	if(sum == j )
		printf("Silnoye chislo");
	else
		printf("!!!!!");
	}






/*
	// mutq tivy reserv ani u stugi asemblora te che
y = x;
	for( ; x != 0 ; x/=10)
	{
		sum *= 10;
		sum += x % 10;		
	}
	printf("%d\n",sum);
	printf("%d\n",y);
	
	if(sum == y)
		printf("nuyna");
	else
		printf("!!!!!!");





	while(x != 0)
	{
		sum += x % 10;		
		x  = x / 10;
	}
*/

	return 0;
}

