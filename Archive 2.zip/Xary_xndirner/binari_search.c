#include <stdio.h>
int fact(int* arr,int size,int target,int left,int right)
{
	int mid=((left+right)/2);

if(left <= right){
	if (arr[mid] == target) 
		return mid;

	if(arr[mid]<target)
		return fact(arr,size,target,mid+1,right);
		
	 
	if(arr[mid]>target)
 	  	return  fact(arr,size,target,left,mid-1);
}
return -1;		

	
}

int main ()
{
	int arr[] = {2,4,6,7,9,16,79};
	int size = sizeof(arr) / sizeof(arr[0]);
	int target;
	scanf("%d",&target);
	int left = 0;
	int right = size - 1;
	printf("%d",fact(arr,size,target,right,left));
	
}
