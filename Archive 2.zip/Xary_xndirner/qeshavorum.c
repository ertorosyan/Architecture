#include <stdio.h>


//  fibonachi qeshavorumov
int fib(int n){
	static int arr[10] = {0,1};
	if(n == 0)
		return 0;
	if(arr[n] != 0)
		return arr[n];
	
	return arr[n] = fib(n-1) + fib(n-2);
	
}
//  factorial qeshavorumov
int fac(int x){
	static int arr[10]= {0,1};
	if(x == 0)
		return 0;
	if(arr[x] != 0){
		return arr[x];
	}
	return arr[x] =  x * fac(x-1);
}
int main(){
	int x ;
	int i = 0;
	
	printf("%d\n",fib(7));
	
}
