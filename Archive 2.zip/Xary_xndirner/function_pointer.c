#include <stdio.h>
#include <string.h>
#define SIZE 10


/// function pointerov xntir vory mi zangvacic zuyq tvery qcuma taza zangvaci mej

void copy(int *arr,int arr_size,int *brr,
				int (*fun)(int) ){  // haytararum enq POINTER FUNCTION wor luboy int  
									// veradarcnox u int argument unecox functiayi hamar hasanelia
									//  int (*blabla) (int)
	
		for(int i = 0 ; i < SIZE ; ++i){
			brr[i] = 0;
		}
	
		for (int i = 0 , j = 0; i < arr_size ; ++i){
				if(fun(arr[i]))
					brr[j++] = arr[i];
		}	
}	

// zuyq tver

int zuyq(int x){
	return x % 2 == 0;
}

// drakan tver
int drakan(int x){
	return x > 0;
}

// bacasakan tver
int bacasakan(int x){
	return x < 0;
}

int main(){ 
	int arr[] = {1,2,5,-1,23,8,-34,-23};	
	int (*array_pointers[])(int) = {zuyq,drakan,bacasakan}; //drakan bacaskan zuyq  functianeri array
	int arr_size = sizeof(arr)/sizeof(int);
	int brr[SIZE];
	
	copy(arr,arr_size,brr,array_pointers[1]);
	for(int i = 0 ; i < SIZE ; ++i){
		printf(" %d",brr[i]);
	}
	 
}





