#include <stdio.h>
#include <stdbool.h>

// gtnel ankyunagcic nerqev en tvery voronq fibonachiyi twer en

bool fib(int n){
	int a = 0;
	int b = 1;
	while(a < n){
		int tmp = a + b;
		a = b;
		b = tmp;
		if(tmp == n  || n  == 0 )
			return true;
	}
	return false;
}



void print_f(int arr[][4],int row,bool(*ptr)(int)){
	for (int i = 0 ; i < row ; ++i){
		for (int j = 0 ; j < row ; ++j){
			if (i > j ){
				if( ptr(arr[i][j])){
					printf("%d ",arr[i][j]);
				}
			}
		}
	}
}


int main() {
    int arr[][4] = { {1, 2, 3, 4},
					{5, 6, 7, 8},
					{9, 10,11,12},
					{13,14,15,16}};					
	
	print_f(arr,4,fib);
}

