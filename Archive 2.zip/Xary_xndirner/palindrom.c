#include <stdio.h>
#include <stdbool.h>


// gtnel ankyunagcic werev en tveri artadryaly woronq palidrom en
bool palindrom(int x){
	int original_x = x;
	int rev = 0;
	while(x){
		rev = rev *  10 + x % 10;
		x /= 10;
	}
	return original_x == rev;
}


int sum_palidrom(int matrix[][4],int row,bool(*ptr)(int)){
	int sum = 1;
	for(int i = 0 ; i < row ; ++i ){
		for(int j = 0 ; j < row	 ; ++j ){
			if(i < j ){
				if( ptr(matrix[i][j]))
					sum *= matrix[i][j];
			}
		}
	}
	return sum;
}
int main(){

	int row = 4;
	int matrix[][4] =   {{11,12,12,5},
						 {12,12, 8,9},
						 {11,21,2,9},
						 {6,7,8, 9},
								  };
	printf("sum = %d", sum_palidrom(matrix,4,palindrom));


}

