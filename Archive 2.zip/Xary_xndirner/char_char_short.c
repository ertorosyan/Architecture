#include <stdio.h>

void foo(int target, char c1, char c2, short sh){
	char *p = (char*)&target;
	*p = c1;
	*(p+1) = c2;
	short *p_sh = (short*)&target;
	*(p_sh + 1) = sh;
	printf("%d ",target);
}


int main(){
	int target = 0 ;
	foo(0,'a','b',5);
}
