#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
int Adder(int op1, int op2);
    int Subtractor(int op1, int op2);
    int Write_to_file(void);
    int mov(char *op1, char *op2);
    int load(char *Rdest, char* addres);
    int store(char *Rdest, char *addres);
    void layo(void);
    int disc(char *op);
    int alu(char *arr, char* dest, char *op1, char*op2);
    void cu(void);

char *oper3 = " ADD SUB ";
char *oper2 = " MOV LOAD STORE ";
char *valid = " START EXIT DISC LAYO ";
char *reg = " R0 R1 R2 R3 R4 R5 ";
char buf[10];
struct memory {
    int registers[6];
    char ram[256];
} typedef Memory;
Memory ob;
int WSR = 0;
int IP = 0;
int fd = 0;

int main() {
    printf("Welcome to the CPU simuliator\nHere you can do several assembly comands\nbut if you want to start the program write START\nand if you want to start all from zero write EXIT\nif you write EXIT twice the program will end\nyou can do MOV, ADD, SUB, STORE, LOAD, LAYO and DISC commands\n");
    cu();
}


int Write_to_file(void) {
    if(write(fd, &ob, sizeof(ob)) == -1) {
        return 1;
    }
    return 0;
}
int Adder(int op1, int op2){
    return op1 + op2;
}
int Subtractor(int op1, int op2) {
    return op1 - op2;
}

int mov(char *op1, char *op2) {
    char op1_for_sprintf[10] = {0};
    char op2_for_sprintf[10] = {0};
    sprintf(op1_for_sprintf, " %s ", op1);
    sprintf(op2_for_sprintf, " %s ", op2);
    int Index_for_register = 0;
    int Index_or_literal_value = 0;
    int flag = 0;
    if(strstr(reg, op1_for_sprintf) != NULL) {
        Index_for_register = op1[1] - '0';
        if(Index_for_register < 0 || Index_for_register > 5) {
            return 1;
        }
    }else {
        return 1;
    }
    if(strstr(reg, op2_for_sprintf) != NULL) {
        Index_or_literal_value = op2[1] - '0';
        if(Index_or_literal_value < 0 || Index_or_literal_value > 5) {
            return 1;
        }
        flag = 1;
    }else if((Index_or_literal_value = atoi(op2)) == 0) {
        return 1;
    }
    if(flag){
        ob.registers[Index_for_register] = ob.registers[Index_or_literal_value];
    } else {
        ob.registers[Index_for_register] = Index_or_literal_value;
    }
    IP++;
    if(Write_to_file() == 1) {
        return 1;
    }
    return 0;
}


int load(char *Rdest, char* addres) {
    int Register_index = 0;
    int Addres_in_ram = 0;
    if(*addres == '0' && *(addres + 1) == '\0') {
        Addres_in_ram = 0;
    }else if((Addres_in_ram = atoi(addres)) == 0) {
        return 1;
    }
    if(strstr(reg, Rdest) != NULL) {
        Register_index = Rdest[1] - '0';
        if(Register_index < 0 || Register_index > 5) {
            return 1;
        }
    }else {
        return 1;
    }
    ob.registers[Register_index] = ob.ram[Addres_in_ram];
    IP++;
    if(Write_to_file() == 1) {
        return 1;
    }
    return 0;
}


int store(char *Rdest, char *addres) {
    int Register_index = 0;
    int Addres_in_ram = 0;
    if(*addres == '0' && *(addres + 1) == '\0') {
        Addres_in_ram = 0;
    } else if((Addres_in_ram = atoi(addres)) == 0) {
        return 1;
    }
    if(strstr(reg, Rdest) != NULL) {
        Register_index= Rdest[1] - '0';
        if(Register_index< 0 || Register_index > 5) {
            return 1;
        }
    }else {
        return 1;
    }
    ob.ram[Addres_in_ram] = ob.registers[Register_index];
    IP++;
    if(Write_to_file() == 1) {
        return 1;
    }
    return 0;
}


void layo(void) {
    for(int i = 0; i < 6; ++i) {
        printf("R%d -> %d,  ", i, ob.registers[i]);
    }
    printf("\n");
    printf("Memori size 256 \n");
    for(int i = 0; i < 256; ++i) {
        printf("%d ", ob.ram[i]);
    }
    printf("\n");
}


int disc(char *op) {
    int DiscPosition;
    if((DiscPosition = atoi(op)) == 0) {
        return 1;
    }
    if(lseek(fd, 0, SEEK_SET) == -1) {
        return 1;
    }
    memset(&ob, 0, sizeof(ob));
    IP -= (DiscPosition);
    if(IP < 0) {
        IP = 0;
    }
    for(int j = 0; j <= IP; ++j) {
        if(read(fd, &ob, sizeof(Memory)) == -1) {
            return 1;
        }
    }
    return 0;
}


int alu(char *arr, char* dest, char *op1, char*op2) {
    int Iindex_for_registers = 0;
    int Operand_1 = 0;
    int Operand_2 = 0;
    if(strstr(reg, dest) != NULL) {
        Iindex_for_registers = dest[1] - '0';if(Iindex_for_registers < 0 || Iindex_for_registers > 5) {
            return 1;
        }
    }
    if(op1[0] >= '0' && op1[0] <= '9') {
            if((Operand_1 = atoi(op1)) == 0) {
                return 1;
            }
    }else {
        if(strstr(reg, op1) != NULL) {
            Operand_1 = op1[1] - '0';
            if(Operand_1 < 0 || Operand_1 > 5) {
                return 1;
            }else {
                Operand_1 = ob.registers[Operand_1];
            }
        }else {
            return 1;
        }
    }
    if(op2[0] >= '0' && op2[0] <= '9') {
            if((Operand_2 = atoi(op2)) == 0) {
                return 1;
            }
    }else {
        if(strstr(reg, op2) != NULL) {
            Operand_2 = op2[1] - '0';
            if(Operand_2 < 0 || Operand_2 > 5) {
                return 1;
            }else {
                Operand_2 = ob.registers[Operand_2];
            }
        }else {
            return 1;
        }
    }
    if(strcmp(arr, "ADD") == 0) {
        ob.registers[Iindex_for_registers] = Adder(Operand_1, Operand_2);
    }else if(strcmp(arr, "SUB") == 0) {
        ob.registers[Iindex_for_registers] = Subtractor(Operand_1, Operand_2);
    }
    IP++;
    if(Write_to_file() == 1) {
        return 1;
    }
    return 0;
}


void cu(void) {
    char instruction[100] = {0};
    while (1) {
        fgets(instruction, 99, stdin);
        instruction[strcspn(instruction, "\n")] = '\0';
        fflush(stdin);
        if(WSR == 0) {
            if(strcmp(instruction, "START") == 0) {
                fd = open("file.txt", O_RDWR | O_CREAT | O_TRUNC, 0666);
                if(Write_to_file() == 1) {
                    printf("the memori does not saved\n");
                }
                WSR = 1;
            }else if(strcmp(instruction, "EXIT") == 0) {
                exit(0);
            }
        }else {
            char arr[10] = {0};
            int Index_for_instruction = 0;
            int Index_for_apcode = 0;
            while(instruction[Index_for_instruction] != ' ') {
                arr[Index_for_apcode++] = instruction[Index_for_instruction++];
            }
            // for ADD and SUB
            if(strstr(oper3, arr) != NULL) {
                char op1[10] = {0};
                char op2[10] = {0};
                char dest[10] = {0};
                while(instruction[Index_for_instruction] == ' ') {
                    Index_for_instruction++;
                }
                Index_for_apcode = 0;
                while(instruction[Index_for_instruction] != ',' && instruction[Index_for_instruction] != ' ' && instruction[Index_for_instruction] != '\0') {
                    dest[Index_for_apcode++] = instruction[Index_for_instruction++];
                }
                while(instruction[Index_for_instruction] == ' ' || instruction[Index_for_instruction] == ',' && instruction[Index_for_instruction] != '\0') {
                    Index_for_instruction++;
                }
                Index_for_apcode = 0;
                while(instruction[Index_for_instruction] != ',' && instruction[Index_for_instruction] != ' ' && instruction[Index_for_instruction] != '\0') {
                    op1[Index_for_apcode++] = instruction[Index_for_instruction++];
                }
                while(instruction[Index_for_instruction] == ' ' || instruction[Index_for_instruction] == ',' && instruction[Index_for_instruction] != '\0') {
                    Index_for_instruction++;
                }
                Index_for_apcode = 0;
                while(instruction[Index_for_instruction] != ' ' && instruction[Index_for_instruction] != '\0')  {
                    op2[Index_for_apcode++] = instruction[Index_for_instruction++];
                }
                if(alu(arr, dest, op1, op2) == 1) {
                    printf("the instruction does not work\n");
                }
            }
            else if(strstr(oper2, arr) != NULL) {
                char op1[10] = {0};
                char op2[10] = {0};
                while(instruction[Index_for_instruction] == ' ') {Index_for_instruction++;
                }
                Index_for_apcode = 0;
                while(instruction[Index_for_instruction] != ',' && instruction[Index_for_instruction] != ' ' && instruction[Index_for_instruction] != '\0') {
                    op1[Index_for_apcode++] = instruction[Index_for_instruction++];
                }
                while(instruction[Index_for_instruction] == ' ' || instruction[Index_for_instruction] == ',' && instruction[Index_for_instruction] != '\0') {
                    Index_for_instruction++;
                }
                Index_for_apcode = 0;
                while(instruction[Index_for_instruction] != ' ' && instruction[Index_for_instruction] != '\0')  {
                    op2[Index_for_apcode++] = instruction[Index_for_instruction++];
                }
                if(strcmp(arr, "MOV") == 0) {
                    if(mov(op1, op2) == 1) {
                        printf("the mov instruction does not work\n");
                    }
                }
                else if(strcmp(arr, "LOAD") == 0) {
                    if(load(op1, op2) == 1) {
                        printf("the load does not work\n");
                    }
                }
                else if(strcmp(arr, "STORE") == 0) {
                    if(store(op1, op2) == 1) {
                        printf("the store does not work\n");
                    }
                }
            } else if(strstr(valid, arr) != NULL) {
                if(strcmp(arr, "LAYO") == 0) {
                    layo();
                }else if(strcmp(arr, "EXIT") == 0) {
                    close(fd);
                    memset(ob.registers, 0, 24);
                    memset(ob.ram, 0, 256);
                    WSR = 0;
                }else if(strcmp(arr, "DISC") == 0) {
                    char Operand_for_Disc[10] = {0};
                    while(instruction[Index_for_instruction] == ' ' && instruction[Index_for_instruction] != '\0') {
                        Index_for_instruction++;
                    }
                    int Index_for_operand = 0;
                    while(instruction[Index_for_instruction] != ' ' && instruction[Index_for_instruction] != '\0') {
                        Operand_for_Disc[Index_for_operand++] = instruction[Index_for_instruction++];
                    }
                    if(disc(Operand_for_Disc) == 1) {
                        printf("the disc does not work");
                    }
                }
            }else {
                printf("the instruction is invalid\n");
            }
        }
        memset(instruction, 0, strlen(instruction));
        fflush(stdin);
    }
}