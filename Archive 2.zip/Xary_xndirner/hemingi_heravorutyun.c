#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>


int hamming(int x ,int y){
    int max,min;
    if(x > y ){
        max = x;
        min = y; 
    }else if(x < y){
        max =y;
        min = x; 
    }
    int count = 0;
    while(max){
        if(((max & 1) ^ (min & 1)) == 1 )
            count++;
        max >>= 1;
        min >>= 1;
    }   
    return count;
}


int main(){
    int x;
    int y;
    printf("Enter number 1 : ");
    scanf("%d",&x);
    printf("Enter number 2 : ");
    scanf("%d",&y);

    pid_t proc = fork();
    if(proc < 0){
        perror("Error !");
        exit(1);
    }else if(proc == 0){
        printf("\n%d\n",hamming(x,y));
        return 0;
    }else
        wait(NULL);
    
}