#include <stdio.h>
#define r 3
#define c 2

//Գրել ծրագիրը, որտեղ հայտարարված կլինի զանգվածների զանգված, ա յսինքն char-երի զանգված որտ եղ կան մի քանի ա յլ char-երի զանգվա ծներ։ Տպ ել ա յն զա նգվածը որտ եղ  չկա թվեր։


int main(){
	
	char arr[r][c] = {
						{'a','9'},
						{'d','7'},
						{'$','$'},
								};

	char new_arr[r];

	for(int i = 0 ; i < r; ++i){
		int count = 0;
		for(int j = 0 ; j < c ; ++j){
			if(arr[i][j] < '0' || arr[i][j] > '9'){
				new_arr[count] = arr[i][j];
				count++;
			}	
		}
		if(count == 2)
			break;
//		printf("aaaaaaaaaaa\n");
	}	
	
	for(int i = 0 ; i < r ; ++i)
		printf("%c ", new_arr[i]);

}

