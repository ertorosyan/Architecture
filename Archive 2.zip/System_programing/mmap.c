/*
11. Գրել ծրագիր, որը թույլ կտա parent process-ին և child process-ին հաղորդակցվել միմյանց հետ: 
Օգտագործել shared memory (mmap) shared հիշողություն ստեղծելու համար: 
parent process-ը գրում է տվյալներ shared memory-ում, իսկ  child process-ը մշակում է տվյալները։
Օրինակ՝ եթե փոխանցել է թիվ գտնում է թվի քառակուսին և պատասխան նամակով հետ ուղարկում։
*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
 #include <sys/mman.h>

int main(){
    int num;
    int fd = open("file.txt", O_RDWR);
    dprintf(fd,"5");
    char* str = mmap(0 , 300 , PROT_READ | PROT_WRITE , MAP_SHARED , fd , 0);

    pid_t proc = fork();
    if(proc < 0)
        perror("ERror");
    else if(proc == 0){
        num = atoi(str) * 2 ;
        dprintf(fd," %d ",num);
        printf("%s\n",str);
        return 0;
    }else
        wait(NULL);


}