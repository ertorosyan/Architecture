#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h> 



void matrix(int size){

    int** arr = (int**)malloc(size * sizeof(int*));
    for(int i = 0 ; i < size ; i++)
        arr[i] = (int*)malloc(sizeof(int) * size );
    
    for(int i = 0 ; i < size ; i++)
        for (int  j = 0; j < size; j++)
            arr[i][j] = rand() % 6 + 1; 

    for(int i = 0 ; i < size ; i++){
        for (int  j = 0; j < size; j++){
            if(i == j){
                printf("%d ",arr[i][j]);
            }
        }
    }

    for(int i = 0 ; i < size ; i++){
        free(arr[i]);
    }
    free(arr);
}

int factorial_rec(num){
    if(num == 0)
        return 1;
    return num * factorial_rec(num-1);
}

int main(){
        // int matrix_size,num;
        // printf("Enter Matrix size : ");
        // scanf("%d",&matrix_size);
        // printf("Enter Number : ");
        // scanf("%d",&num);

        // // ptroces matrix
        // pid_t print_matrix = fork();
        // if(print_matrix < 0)
        //     perror("Error");
        // else if(print_matrix == 0){
        //     printf("child PID = %d\n",getpid());
        //     matrix(matrix_size);
        //     return 0;
        // }
        // else if(print_matrix > 0)
        //     waitpid(print_matrix,NULL,0);

        // //preoces factorial
        //  pid_t factorial = fork();
        // if(factorial < 0)
        //     perror("Error");
        // else if(factorial == 0){
        //     printf("\nchild PID = %d\n",getpid());
        //     printf("factorial = %d\n",factorial_rec(num));
        //     return 0;
        // }
        // else if(factorial > 0)
        //     waitpid(factorial,NULL,WNOHANG);



    //sort process for PID

}
