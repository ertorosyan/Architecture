#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>


int main(){
    pid_t proc = fork();
    if(proc < 0)
        perror("Error");
    else if(proc == 0){
        char *args[]={"ls","-lG",NULL};
        execv("/bin/ls",args);
    }
    else if(proc > 0)
    {
        wait(NULL);
    }
    printf("\n");
    return 0;
}