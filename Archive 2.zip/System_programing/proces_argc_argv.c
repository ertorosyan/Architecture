/**
 1)
 Գրել ծրագիր, որի կատարման արդյունքում գրելով ./a.out 1 2 3 4 … n, 
 կտպի էկրանին a.out-ից հետո գրված թվերի գումարը։
*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(int argc,char *argv[]){
    // // 1)
    // int sum = 0;
    // for (int i = 1; i < argc; i++){
    //     sum += atoi(argv[i]);
    // }
    // printf("%d\n",sum);


    int *arr = (int*)malloc((argc-1) * sizeof(int));

    for(int i = 0 , j = 1 ; j < argc ; ++i,++j){
        arr[i] = atoi(argv[j]) + 5 ;
    }

    for (int i = 0; i < argc-1; i++)
    {
        printf("%d ",arr[i]);
    }
    
    free(arr);
    
}