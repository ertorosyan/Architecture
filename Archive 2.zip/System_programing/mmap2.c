/*
Задача 5. Сложная связь с помощью mmap() и fork().
Цель: реализовать более сложный сценарий, включающий общую память и управление процессами.
Требования:
Расширьте свою программу задачи 4, чтобы создать общую структуру данных
 (например, массив целых чисел) в области общей памяти.
Родительский процесс заполняет эту общую структуру данных данными.
Дочерние процессы читают эту структуру данных и выполняют простую операцию
(например, суммирование целых чисел).
Руководство по внедрению 
Обработка ошибок: каждая задача должна включать надежную обработку ошибок для всех системных вызовов.
 Это имеет решающее значение для разработки надежных системных приложений.
Документация кода: четко комментируйте свой код, чтобы описать ключевые решения и механизмы.
 Это поможет понять ваш подход к реализации.
Тестирование: тестируйте свои программы в различных сценариях и входных данных,
 чтобы убедиться, что они корректно обрабатывают крайние случаи.
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/mman.h>
#include <fcntl.h>



int main(){
    int fd = open("file.txt",O_RDWR);  // open file
    int *shared_memory = mmap(NULL,4 * sizeof(int),PROT_READ | PROT_WRITE ,MAP_SHARED , fd ,0); // take space(mmap)
    // mmap -> true or false
    if (shared_memory == MAP_FAILED) {
        perror("mmap !");
        exit(1);
    }
    // elements for array 
    for (int i = 0; i < 3; i++)
    {
        shared_memory[i] = i+1;
    }
    
    int sum = 0;

    pid_t proc = fork();
    if(proc < 0){
        perror("Error fork");
        exit(1);
    }
    else if(proc == 0){
        for (int i = 0; i < 3; i++){
            sum += shared_memory[i];
        }
        printf("Count element is array = %d\n",sum);
        return 0;   //kill chid process
    }
    else
        wait(NULL);

    // FREE space mmap
    int unmma = munmap(shared_memory, 4 * sizeof(int));
    if (unmma == -1){
        perror("munmap !");
    }
    
}