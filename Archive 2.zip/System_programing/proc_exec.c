/*
10. .Գրել ծրագիր, որի կատարման ժամանակ թույլ կտա օգտվողին մուտքագրել Linux-ական հրամաններ,
 այնքան ժամանակ քանի դեռ չի մուտքագրել exit բառը։ Իրականացնել ֆունկցիա, 
 որը մուտքագրված հրամանը կստանա որպես արգումնետ և կստեղծի child պրոցես, 
 որի կատարման արդյունքում կտեսնենք հրամանի կատարման արդյունքը տերմինալում։
*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <stdbool.h>
#include <sys/wait.h>

bool tt(char* str){
    int cmp = strcmp(str,"exit");
    if(cmp == 0)
        return true;
    else 
        return false;
}


int main(){
    char* str;
    printf("Enter your command in linus : ");

    do{
        fgets(str,10,stdin);

        if(tt(str) == 1)
            exit(0);

        pid_t proc = fork();
        if(proc < 0)
            perror("Error");
        else if(proc == 0){
            system(str);
            return 0;
        }
        else if(proc > 0 )
            wait(0);
    }while(tt(str) != 1);
}