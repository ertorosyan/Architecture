/*
Требования:
Реализуйте программу на языке C, в которой родительский процесс создает в цикле несколько дочерних процессов.
Каждый дочерний процесс должен выполнять отдельную команду с помощью exec(). 
Предлагаемые команды: ls, whoami, date.
Родительский процесс должен дождаться завершения выполнения всех дочерних процессов, прежде чем завершиться.
Включите проверку ошибок для каждого системного вызова (fork(), exec(), wait()),
 чтобы обеспечить надежность.
*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(){

    pid_t proc[3];
    char str[10];

    for (int i = 0; i < 3; i++)
    {
        printf("Enter comand to file '/bin' : ");
        scanf("%s",str);
        proc[i] = fork();
        if(proc[i] < 0){
            perror("Don't create process");
        }
        else if(proc[i]  == 0){
            printf("Hello from Child! %d\n",getpid());
            int fd = execlp(str,str,NULL);
            perror("execlp !!!");
            return 0;
        }
        else{
            wait(NULL);
            
        }
    }
    

}