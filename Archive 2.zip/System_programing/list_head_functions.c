#include <stdio.h>
#include <stdlib.h>

typedef struct Node{
    int value;
    struct Node * next;
}Node;

//add node
void addElement(Node **head, int data){
    Node *tmp = (Node *)malloc(sizeof(Node));
        if(tmp == NULL){
            fprintf(stderr,"Error");
            exit(1);
        }
    if(*head == NULL){
        tmp->value = data;
        tmp->next = NULL;
        (*head) = tmp;
        return;
    }else{
        Node* last = *head;
        while (last->next != NULL){
            last = last->next;
        }
        tmp->value = data;
        tmp->next = NULL;
        last->next = tmp;
        return;
    }
}
// add node from first
void addprepend(Node **head, int data){

    Node *start = malloc(sizeof(Node));
    if(start == NULL){
        fprintf(stderr,"Error");
        exit(1);
    }
    
    start->next = *head;
    start->value = data;
    *head = start;
}

// add element to list , index -x
void insertAfter(Node **head,int index ,int data){
    Node * ptr = *head;
    Node *new_list = malloc(sizeof(Node));
        if(new_list == NULL){
            printf("Error");
            exit(1);
        }
    if(index == 0){
            new_list->value = data;
            new_list->next = ptr;
            *head = new_list;
            return;
        }
    int idn = 0;
    while (ptr != NULL){
        if(idn == index-1 ){
            new_list->value = data;
            new_list->next = ptr->next;
            ptr->next = new_list;
            return;
        }
        ptr = ptr->next;
        idn++;
    }
}

// delete one list
void deleteNode(Node **head ,int index){
    Node * ptr = *head;
    int ind = 0;
    if(index == 0){
            Node *tmp = ptr;
            *head = ptr->next;
            free(tmp);
            return;
    }
    while(ptr->next != NULL){
        if(ind == index -1 ){
            Node *tmp =ptr->next;
            ptr->next = ptr->next->next;
            free(tmp);
            return;
        }
        ++ind;
        ptr = ptr->next;
    }
}
//Return 1 if the list is empty or 0 otherwise.
int isEmpty(Node * head){
    if(head  == NULL)
        return 1;
    else
        return 0;
}
//Return the count of elements.
int getSize(Node * head){
    int count = 0;    
    while(head){
        count++;
        head = head->next;
    }
    return count;
}
//return the address of the first node that has the swapped value, if not NULL
Node * find(Node** head,int find_data){
    Node* tmp = *head;
    while(tmp != NULL){
        if(tmp->value == find_data)
            return tmp;
        tmp = tmp->next;
    }
    return NULL;
}

// print list
void print_list(Node * ptr){
     while (ptr){
        printf("%d ",ptr->value);
        ptr = ptr->next;
    }
}
// clear list
void free_list(Node ** head){
    while (*head != NULL)
    {
        Node * tmp = *head;
        *head = (*head)->next;
        free(tmp);
    }
}
void reverse(Node **head){
    Node *curent = *head;
    Node *prev = NULL;
    Node *next = NULL;
    while (curent){
        next = curent->next;
        curent->next = prev;
        prev = curent;
        curent = next;
    }
    *head = prev;
}

Node * reverve_rekursia(Node *head,Node *prev){
    if(head == NULL)
        return prev;
    Node *next = head->next;
    head->next = prev;

    return reverve_rekursia(next,head);
}


int main(){
    Node * head = NULL;
    // // scan list element
    for(int i = 0 ; i < 5 ; i++)
        addElement(&head,i);
    Node *current = head;
    print_list(head);
    
    printf("\n");
    reverse_rekursia(head,current);
    // deleteNode(&head,4);
    print_list(head);

    free_list(&head);


}