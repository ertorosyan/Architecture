//Գրել ծրագիր, որը կստեղծի 15 child process սորտավորել pid-ները։


#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h> // Для функции wait
#include <stdlib.h>

int main() {
    int id[5];
    
    pid_t proc_arr[5];

    for (int i = 0; i < 5; i++) {
        proc_arr[i] = fork();
        // id[i] = getpid();

        if (proc_arr[i] < 0) {
            perror("Error 'fork'");
            exit(1);
        } else if (proc_arr[i] == 0) {
             getpid();
            exit(0);
        }
        else{

            id[i] = wait(NULL);
        
        }
    }

    for (int i = 0; i < 5; i++) {
        printf("%d ", id[i]);
    }

    printf("\n");

    return 0;
}
