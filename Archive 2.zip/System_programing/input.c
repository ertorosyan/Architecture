/*
Ստեղծել երկու C-ական ֆայլ(ծրագիր), 
առաջին ծրագրի կատարման ժամանակ համապատասխան system call-ի արդյունքում
կդադարեցվի առաջին ծրագիրի աշխատանքը և կսկսի կատարվել 2-րդ ֆայլում գրված կոդը։ 
*/
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>


int main(){
        pid_t proc = fork();
        if(proc < 0 )
            perror("Eroor");
        else if(proc == 0){
            if (execl("./process", NULL) == -1 )
                printf("NOOO\n");
        }
        else
            wait(NULL);
        
}