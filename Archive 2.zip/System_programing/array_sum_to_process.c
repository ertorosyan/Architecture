/*
Напишите программу, которая вычисляет сумму массива с помощью параллельной обработки.
Разделите массив на равные сегменты и создайте дочерние процессы
для одновременного вычисления суммы каждого сегмента. Наконец, просуммируйте частичные результаты,
полученные от каждого дочернего процесса в родительском процессе.
*/
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/mman.h>

int main(){

    int* sher_mem = mmap(NULL,sizeof(int),PROT_READ | PROT_WRITE ,MAP_SHARED | MAP_ANONYMOUS , -1 ,0 );
    int arr[4] = {1,1,1,1};
    int index2 = 2;
    int sum = 0;
    int size = 4;

    pid_t proc = fork();
    if(proc < 0){
        perror("Fork error");
        exit(1);
    }else if(proc == 0){
        for(int i = 0 ; i < index2 ;++i){
            sum += arr[i];
        }
        sher_mem[0] = sum;
        return 0;
    }else{
        wait(NULL);
        pid_t proc = fork();
            if(proc < 0){
                perror("Fork erxror");
                exit(1);
            }else if(proc == 0){
                for(int i = index2 ; i < size ;++i){
                    sum += arr[i];
                }
                sher_mem[0] += sum ;
                return 0;
            }else{
                wait(NULL);
            }
    }

    printf("%d",sher_mem[0]);
    int unmma = munmap(sher_mem,sizeof(int));
    if (unmma == -1){
        perror("\nmunmap !");
    }
}