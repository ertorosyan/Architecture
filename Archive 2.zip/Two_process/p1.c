#include <stdio.h>
#include <unistd.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <stdlib.h>


int main(){

	int x = open("./baza.txt",O_CREAT | O_RDWR,0777);
	char* ptr = mmap(NULL, 500 ,PROT_READ | PROT_WRITE , MAP_SHARED, x ,0 );	
	if(ptr == MAP_FAILED){
		fprintf(stderr,"ERROR");
		exit(1);
	}
	ptr[0] = 20;
return 0;
}
