#include <stdio.h>
#include <stdlib.h>

	// CONCAT STRING 1 & STRING 2


char* concat_string(char* s1 , char* s2 , int size_string){

	// SIZE s1
	int count1 = 0;
	int i = 0;
	while(s1[i] != '\0'){
		++count1;
		++i;
	}
	// SIZE s2
	i = 0;
	while(s2[i] != '\0'){
		++i;
	}
	int count2 = i;
	//---------------------------------------------------
	// NO REALLOC
	if(count1 + count2 + 1 < size_string){
		int i = 0;
		while(i < count2){
			s1[count1] = s2[i];
			count1++;
			i++;
		}
		s1[count1] = '\0';
	}else{    // REALLOC
		s1 = (char*)realloc(s1,count1 * 2);
		int i = 0;
		while(i < count2){
			s1[count1] = s2[i];
			count1++;
			i++;
		}
		s1[count1] = '\0';
	}
	return s1;
}


int main(){
	
	int size_string = 8;
	// SCANF STRING 1
	char* str1 = (char*) malloc(size_string * sizeof(char) );
	printf("Enter your str1\n");
	scanf("%s",str1);

	// SCANF STRING 2
	char* str2 = (char*) malloc(size_string * sizeof(char) );
	printf("Enter your str1\n");
	scanf("%s",str2);
	
	str1 = concat_string(str1,str2,size_string);
	printf("%s",str1);

	free(str1);
	free(str2);

}
