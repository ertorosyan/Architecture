#include <stdio.h>
#include <stdlib.h>

int Strlen(char* str){
	int i = 0;
	while(str[i] != '\0')
		++i;
	return i;
}


char** ft_split(char *str, char c){
	
	
	int size = Strlen(str);
	int i = 0;		
	int word  = 0;

	while(str[i] != '\0'){										//bareri qanaky
		if( i == (size-1) || (str[i] != c && str[i+1] == c) ) 
			word++;
		++i;
	}

	i = 0;

	int count_sym = 0;
	int max_sym = 0;
	while(str[i] != '\0'){    //amenamec bari simvolneri qanaky

		if(str[i] != c){
			count_sym++;
		}

		if(str[i] == c)
			count_sym = 0;
		++i;	
	}

		//alocate matrix	
		char** arr = (char**)malloc ((word + 1) * (sizeof(char*)));
		arr[word] = NULL;
		for(i = 0; i < word ; ++i){
			arr[i] = (char*)calloc( max_sym + 1, sizeof(char));
		}
		
	int k = 0;
	i = 0;
	while (arr[i])
	{
		int j = 0;
		while (str[k] != '\0' && str[k] == c)
				k++;
		while(str[k] != '\0' && str[k] != c)
			arr[i][j++] = str[k++];
		while (str[k] != '\0' && str[k] == c)
			k++;
		i++;
	}
	
	return arr;	
}




int main(){
				// arr  0 		1
				//		Hellow  world
				// printf("%s\n", arr[0][0]);  --> H

	char* str = "H,e,llo,Wor,   ld";
	char delimn = ',';
	

	char** arr = ft_split(str,delimn);
	int i ;
	
	//print matrix
	for(int i = 0 ; arr[i] != NULL ; ++i){
		printf("%s\n", arr[i]);
	}
	
		// free memory
		for(i = 0; arr[i] != NULL ; ++i){
			free(arr[i]);
		}	
		free(arr);

}
