#include <stdio.h>
#include <stdlib.h>

// 	Գրել ֆունկցիա, որը ստանում է զանգված և էլեմենտ։
// 	Ավելա ցնել էլեմենտը զանգվածի վերջից։ Եթե զանգվածում տեղ չկա մեծացնել զանգվածը նոր  ավելացնել։
// 	(push_back)

void push_back(int* arr,int* size , int* cap ,int element){
	if(*size == *cap){
		(*cap) *= 2;
		arr = (int*)realloc(arr,*cap * sizeof(int));
		arr[*size] = element;
		(*size)++;
	}else{
		arr[*size] = element;
		(*size)++;
	}
}
int main(){
	int size = 3;
	int cap = 3;
	int* arr = (int*)malloc(cap * sizeof(int));
	arr[0] = 1;
	arr[1] = 2;
	arr[2] = 3;
	int element = 4;
	push_back(arr,&size,&cap,element);

	for(int i = 0 ; i < size ;++i)
		printf("%d ",arr[i]);
	printf("\ncap = %d\n",cap);
}