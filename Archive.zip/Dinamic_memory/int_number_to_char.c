#include <stdio.h>
#include <stdlib.h>

void swap(char* x , char* y){
    int tmp = *x;
    *x = *y;
    *y = tmp;
}

void int_to_char(int x){
    int tvanshan = 0;
    int copy_x = x;

    while (copy_x != 0){
        tvanshan++;
        copy_x /= 10;
    }
    char* str =(char*)malloc((tvanshan + 1) * sizeof(char));
    int i = 0;

    while (x != 0){
        str[i] = 48 + (x % 10);
        x /= 10;
        i++;
    }
    str[i] = '\0';

    for(int k = 0 , l = i -1; k  < i / 2 ; k++ , l--){
        swap(&str[k] , &str[l]);
    }

    printf("\n%s\n", str);
    free (str);

}



int main(){
    int x ;
    scanf("%d", &x);
    int_to_char(x);
}