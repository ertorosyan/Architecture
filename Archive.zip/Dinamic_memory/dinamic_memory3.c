#include <stdio.h>
#include <stdlib.h>

int my_strlen(const char* str){

	int i = 0;
	while(str[i] != '\0'){
		++i;
	}
	return i;
}

// strdup function
char* my_strdup(const char *str ){
	
	int size_str = my_strlen(str);
	char* d_str = (char*)malloc((size_str + 1) * sizeof(char));

	int i = 0;
	while(str[i] != '\0'){
		d_str[i] = str[i];
		++i;
	}
	d_str[i] = '\0';
	return d_str;
}


//  substr function	
char* my_substr(char *s, unsigned int start, size_t len){

	int mijakayq = len - start;
	char* new_str = (char*)malloc((mijakayq + 1) * sizeof(char));
	int i = start;
	int j = 0;
	while(mijakayq >= 0){
		new_str[j] = s[i];
		++i;
		++j;
		--mijakayq;
	}
	new_str[i] = '\0';
	return new_str;	

}

int main(){

	char str[] = {"Hellow World"};
	char* ptr = my_substr(str,2,5);
	printf("%s",ptr);
	free(ptr);
	
}

