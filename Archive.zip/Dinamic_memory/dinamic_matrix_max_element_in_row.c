#include <stdio.h>
#include <stdlib.h>

int max_in_array(int* arr , int size){
	int max = 0;
	for(int i = 1 ; i < size ;++i){
		if (arr[i] > arr[max])
			max = i;
	}
	return arr[max];
}


void  make_matrix(int n , int m){
	
	// make matrix n x m
	int** arr = (int**)malloc(n * sizeof(int*));
	for (int i = 0 ; i < m ; ++i){
		arr[i] = (int*)malloc(m * sizeof(int));
	}
	// scanf matrix
	for(int i = 0 ; i < n ; ++i){
		for(int j = 0 ; j < m ; ++j){
			scanf("%d",&arr[i][j]);			
		}
	}
	printf("\n");
	//print matrix
	for(int i = 0 ; i < n ; ++i){
		printf("\n");
		for(int j = 0 ; j < m ; ++j){
			printf("%d ",arr[i][j]);			
		}
	}
	printf("\n");
	printf("\n");
	// make new array
	
	int* new_arr = (int*)malloc(n* sizeof(int));


	// find max element in row --> new_array

	for(int i = 0 ; i < n ; ++i){
		new_arr[i] = max_in_array(*(arr + i),m);		
	}

	//print new_arr
	for(int i = 0 ; i < n ; ++i){
		printf("%d ",new_arr[i]);
	}

	//free new_arr;
	free(new_arr);
	
	for(int i = 0 ; i < n ; ++i){
		free(arr[i]);
	}
	free(arr);

}


int main() {

	int n,m;
	printf("Mutq tox : ");
	scanf("%d",&n);
	printf("Mutq syun : ");
	scanf("%d",&m);

	make_matrix( n , m);
}

