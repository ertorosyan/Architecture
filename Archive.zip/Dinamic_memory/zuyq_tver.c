#include <stdio.h>
#include <stdlib.h>




int* zuyq_tver(int n){

	int count = 0;
	for(int i = 1 ; i <= n ; i++){
		if(i % 2 == 0)
			count++;
	}

	int* arr = (int*)malloc(count * sizeof(int));


	int j = 0;
	for(int i = 1 ; i <= n ; i++){
		if(i % 2 == 0){
			arr[j] = i;
			j++;
		}
	}

	return arr;

}



int main(){

	int n;
	scanf("%d",&n);
	int* arr = zuyq_tver(n);

	for(int i = 0 ; i < n ; ++i){
			printf("%d ",arr[i]);	
		}
	
	free(arr);
//	system("leaks a.out");
}
