#include <stdio.h>
#include <stdlib.h>


void matrix_max(int n, int m ){
	
	//matrix allocated
	int** arr =(int**)malloc(n * sizeof(int*));
	for(int i = 0 ; i < n ; i++){
		arr[i] = (int*)malloc(m * sizeof(int));
	}

	int max = 0;
	//matrix scanf
	for(int i = 0 ; i < n ; i++){
		for(int j = 0 ; j < m ; j++){
			scanf("%d",&arr[i][j]);
		}
	}


	// max element is matrix	
	for(int i = 0 ; i < n ; i++){
		for(int j = 0 ; j < m ; j++){
			max  = (arr[i][j] > max) ? arr[i][j] : max;
		}
	}

	printf("Max element is matrix(n x m) = %d\n", max );
	
	// free memory
	for(int i = 0 ; i < n ; ++i){
		free(arr[i]);	
	}
	free(arr);
	

}



int main(){
	

	int n,m;
		
	printf("Mutq n ");
	scanf("%d",&n);
	printf("Mutq m ");
	scanf("%d",&m);
	printf("Mutq Matrix \n");
	matrix_max(n,n);		
}

