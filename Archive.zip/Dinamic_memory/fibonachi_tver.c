#include <stdio.h>
#include <stdlib.h>


void fib_num(n){
	int* arr = (int*)malloc(n   * sizeof(int));
	int a = 0;
	int b = 1;

	for (int i = 0 ; i < n  ; i++){
			arr[i] = a;
			printf("%d ",arr[i]);
			int tmp = a+b;
			a = b;	
			b = tmp;
	}
	free(arr);
}

int main(){
	int n;
	scanf("%d",&n);
	fib_num(n);
}
