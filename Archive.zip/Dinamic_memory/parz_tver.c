#include <stdio.h>
#include <stdlib.h>
//  Write a C function get_primes_array that takes an integer n as input and returns an array in 
//  dynamic memory filled with the first n prime numbers. 
//  The function should allocate memory dynamically for the array based on the value of n, 
//  calculate and fill the array with prime numbers, 
//  and return a pointer to the dynamically allocated array.







int* parz_tver(int n){

	int* arr = (int*)malloc(n* sizeof(int));
	int k = 0;     
	for(int i = 2;  k < n ; ++i ){
            int count = 0;
		for(int j = 1 ; j <= i ; ++j){
			if(i % j == 0)
				count++;
		}  
		if(count == 2){
			arr[k] = i;
			++k;
		}
     }
	return arr;
}


int main(){

    int n;
    printf("Mutq tiv :");
    scanf("%d",&n);
    int* arr = parz_tver(n);
	
	for(int i = 0 ; i < n ; ++i){
		printf("%d ",arr[i]);
	}
	free(arr);

}
