#include <stdio.h>
#include <stdlib.h>



void make_matrix(int n, int m){


	// make dynamic matrix
	int **arr = (int**)malloc(n * sizeof(int*));
	for(int i = 0 ; i < n ; ++i){
		arr[i]= (int*)malloc(m * sizeof(int));
	}
	//scanf matrix
	for(int i = 0 ; i < n ; ++i){
		for(int j = 0 ; j < m ; ++j){
			scanf("%d ",&arr[i][j]);
		}
	}
	// print matrix

	for(int i = 0 ; i < n ; ++i){
		printf("\n");
		for(int j = 0 ; j < m ; ++j){
			printf("%d ",arr[i][j]);
		}
	}

	printf("\n");

	// snake print matrix

	for(int i = 0 ; i < n ; ++i){											
		printf("\n");
			if(i % 2 != 0){
				for(int j = m-1 ; j >= 0 ; --j){
					printf("%d " , arr[i][j]);
				}
			}else{
				for(int j = 0 ; j < m ; ++j){
					printf("%d " , arr[i][j]);
				}
			}
	}

	for(int i = 0 ; i < n ; ++i){
		free(arr[i]);
	}
	free(arr);
}



int main(){
	int n;
	int m;
	printf("Mutqagri qani tox lini matrixy : ");
	scanf("%d",&n);
	printf("Mutqagri qani syun lini matrixy : ");
	scanf("%d",&m);

	make_matrix( n, m);

}
