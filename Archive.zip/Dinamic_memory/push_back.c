#include <stdio.h>
#include <stdlib.h>


void pushback(int** ptr ,int element , int* size){
    int compasity = 0;

    if(*size == compasity){
        compasity = *size == 0 ? 1 : compasity * 2;
        *ptr = (int*)realloc(*ptr, compasity);
        if(*ptr == NULL) {exit(1);}
 
    }
    (*ptr)[*size] = element;
    (*size)++;

}


int main(){
    int* arr = NULL;
    int size = 0;
    pushback(&arr,7,&size);
    pushback(&arr,6,&size);
    pushback(&arr,6,&size);
    pushback(&arr,6,&size);
    pushback(&arr,6,&size);

    for(int i = 0 ; i < size ; ++i)
        printf("%d ",arr[i]);
    free(arr);
}