#include <stdio.h>
#include <stdlib.h>


//Malloc ֆունկցիան օգտագործելով իրականացնել Realloc և Calloc ֆունկցիաներին համարժեք ֆունկցիաներ։


int *my_realloc(int *arr, size_t newsize , int size){
	
	if(arr == NULL){
		return malloc(size);
	}
	if(size == 0){
		free(arr);
		return NULL;
	}

	int* new_arr = (int*)malloc(newsize * sizeof(int));

	for(int i = 0 ; i < size ; ++i){
		new_arr[i] = arr[i];
	}
	free(arr);
	return new_arr;
}


int* my_calloc(int bit_count){

	int* arr = (int*)malloc(bit_count * sizeof(int));	

	for(int i = 0 ; i < bit_count ; ++i ){
		arr[i] = 0;
	}

	return arr;
}


int main() {

	int size = 6;
	int* arr = (int*)malloc(size * sizeof(int));
	// arr[0] = 1;
	// arr[1] = 2;
	// arr[2] = 3;
	// arr[3] = 4;
	// arr[4] = 5;
	// arr[5] = 6;
	
	// printf("Skzbnakan array\n");
	// for(int i = 0 ; i < size ; ++i){
	// 	printf("%d ",arr[i]);
	// }
	// int new_size = 4;	
	// printf("Realoc aneluc heto\n");

	// REALLOC
	// arr = my_realloc(arr,new_size, size);
	
	// for(int i = 0 ; i < new_size ; ++i){
	// 	printf("%d ",arr[i]);
	// }
	// free(arr);
	
	
	printf("Calloc enq anum 10 elementanoc array\n");
	
	// CALLOC
	int size1 = 10;
	int* ptr = my_calloc(size1);
	
	free(ptr);
	
	system("leaks a.out");
}

