#include <stdio.h>
#include <stdlib.h>


// Remove Duplicates from Sorted Array (Easy):

void swap(int* x,int*y){
	int tmp = *x;
	*x = *y;
	*y = tmp;
}

void insertion_sort(int* arr,int size){
     for(int i = 1 ; i < size; ++i){  
         int j = i;
         while( j > 0)
         {
             if(arr[j - 1] > arr[j])
                 swap(&arr[j-1],&arr[j]);
             --j;
         }
     }
  }

void print(int* arr, int size){
	for(int i = 0 ; i < size  ; ++i){
		printf("%d ",arr[i]);
	}
}


int* delet(int* arr, int size){

	printf("Mer zangvacy skzbic\n");
	print(arr,size);

	int count = 0;
	int j = size-1;
	for(int i = 0; i < size-1 ; ++i){ 
		if(arr[i] == arr[i+1]){       
			count++; 
			swap(&arr[i],&arr[j]);
			--j;
		}
	}
	arr  = (int*)realloc(arr,(size-count)* sizeof(int));
	insertion_sort(arr, size-count);

	printf("\n");
	printf("Mer zangvacy heto\n");
	print(arr,size-count);

	return arr;
}



int main(){

	int size = 8;
	int* arr = (int*)malloc(size * sizeof(int));
	arr[0] = 1;
	arr[1] = 2;
	arr[2] = 2;
	arr[3] = 2;
	arr[4] = 3;
	arr[5] = 4;
	arr[6] = 4;
	arr[7] = 5;


	delet(arr,size);
	free(arr);
}
