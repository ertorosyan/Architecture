#include <stdio.h>
#include <stdlib.h>


//Динамическое обращение строки: напишите программу,
// которая принимает строку в качестве входных данных,
// динамически выделяет для нее память, переворачивает строку, а затем печатает перевернутую строку.
int main(){

	char* str ;
	scanf("%s",str);
	// strlen in str
	int i = 0;
	while(str[i] != '\0'){
		i++;
	}
	
	char* revers_str = (char*)malloc((i + 1) * sizeof(char));

	int j = 0;
	i--;
	while(i >= 0){
		revers_str[j] = str[i];
		++j;
		--i;
	}
	revers_str[j] = '\0';
	printf("%s\n",revers_str);
	free(revers_str);
	

}

