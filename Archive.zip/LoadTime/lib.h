#ifndef LIB
#define LIB

int foo();
void print();


#endif 
