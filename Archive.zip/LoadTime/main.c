#include <stdio.h>
#include "lib.h"


int main(){
	printf("%d\n",foo());
	print();
}
