#include <stdio.h>

int foo(){
	return 13;
	}

void print(){
	printf("Hellow");
}
