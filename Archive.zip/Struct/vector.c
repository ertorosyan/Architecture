#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>

typedef struct Vector{
    int* vec;
    int size;
    int cap;
}Vector;

int at(const Vector * arr ,int pos){

    return arr->vec[pos] ;
}

bool empty(const Vector *vector){
    if(vector->size == 0)
        return true;
    else 
        return false;

}

void push_back( Vector *vector, int value){
    if(vector->size == vector->cap){
        vector->cap *= 2;
        vector->vec = (int*)realloc(vector->vec, sizeof(int) * vector->cap);
        vector->vec[vector->size] = value;
    }else{
        vector->vec[vector->size] = value;
    }
    vector->size++;
}
void pop_back(Vector * vector){
    vector->vec = (int*)realloc(vector->vec , (vector->size - 1) * sizeof(int));
    vector->size--;
}

int size(const Vector *vector){
    return vector->size;
}

int capacity(const Vector *vector){
    return vector->cap;
}

void insert(const Vector *vector,int pos,int value){
    vector->vec[pos] = value;
}

void initializeVector(Vector * vector, int initialCapacity){
    vector->vec = (int*)malloc(initialCapacity * sizeof(int));
    vector->size = 0;
    vector->cap = initialCapacity;
}

int main(){
    int* arr = (int*)malloc(5 * sizeof(int));
    arr[0] = 1;
    arr[1] = 2;
    arr[2] = 3;
    arr[3] = 4;
    arr[4] = 5;
    Vector myvector = {
        arr,
        5,
        8
    };

    insert(&myvector,2,30);
    for(int i = 0 ; i < myvector.size ; i++)
        printf("%d ",arr[i]);
    free(arr);
}