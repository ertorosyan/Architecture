#include <stdio.h>
#include <stdlib.h>

typedef union A
{   
    char c;
    char b;
    int g;
    int* f;
} A;


typedef struct mainn
{
    int ff;
    char name[6];
    int g;
    A gho;
    char gh;
    char fgh;
    long dfs;

}mainn;


int main()
{
    A obj;
    mainn g;

    printf("struct = %lu\n", sizeof(g));
    printf("%lu\n", sizeof(obj));
    // obj.str = (char *)calloc(4,1);
    // obj.str[0] = '1';
    // obj1 = obj;
   // printf("simvol == %c\n", obj1.arr[0]);
   // printf("%p == %p\n", obj.arr, obj1.arr);
}