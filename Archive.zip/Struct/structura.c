#include <stdio.h>
#include <string.h>

    typedef struct {  
        char name[20];
        char cart_number[20];
        int balance ; 
    }bank;

bank cars(bank obj){
    printf("enter user name : ");
    scanf("%s",obj.name);
    printf("enter cart_number : ");
    scanf("%s",obj.cart_number);
    printf("enter balance : ");
    scanf("%d",&obj.balance);
    return obj;
}

void print(bank obj){
    printf("%s\n",obj.name);
    printf("%s\n",obj.cart_number);
    printf("%d\n",obj.balance);
}


int main (void){
    bank obj[3];
    for (int i = 0; i < 3; ++ i)
        obj[i] = cars(obj[i]);

    for (int i = 0; i < 3; ++ i)
        print(obj[i]);

}
