#include <stdio.h>
#include <stdlib.h>
#define  sze 20


typedef struct information{
    int id;
    char name[sze];
    char position[sze];
    int money;

}Info;

void swap(Info * x,Info *y){
    Info tmp = *x;
    *x = *y;
    *y = tmp;
}

void add_person(Info arr[] ,int * person_count , int count){

    if(*person_count == count){
        printf("Not size for person count");
        exit(1);
    }
    printf("Enter ID for person :");
    scanf("%d",&arr[*person_count].id);

    printf("Enter person Name :");
    scanf("%s",arr[*person_count].name);

    printf("Enter person Position :");
    scanf("%s",arr[*person_count].position);

    printf("Enter person Money :");
    scanf("%d",&arr[*person_count].money);
    (*person_count)++;
}

void remov_person(Info arr[] , int* person_count , int index_remove){
    swap(&arr[index_remove], &(arr[(*person_count - 1)]));
    (*person_count)--;
}
void update(Info arr[] , int index_person , int element ){

    switch (element)
    {
    case 0:
        printf("Enter update ID for person(%d) :",index_person);
        scanf("%d",&arr[index_person].id);
        break;
    
    case 1:
        printf("Enter update person Name(%d) :",index_person);
        scanf("%s",arr[index_person].name);
        break;
    case 2:
        printf("Enter update person Position(%d) :",index_person);
        scanf("%s",arr[index_person].position);
        break;
    case 3:
        printf("Enter update person Money(%d) :",index_person);
        scanf("%d",&arr[index_person].money);
        break;
    }

}

int main(){
    int person_count = 0;
    int count = 10;
    Info work[count];


    add_person(work,&person_count,count);
    // add_person(work,&person_count,count);
    // remov_person(work,&person_count,1);
    // update(work,0,3);

    for(int i = 0 ; i < count ; i++){
        printf("Person %d\n",i);
        printf("Id = %d\n",work[i].id);
        printf("Name = %s\n",work[i].name);
        printf("Poition = %s\n",work[i].position);
        printf("Money = %d\n\n",work[i].money);
    }
}
  