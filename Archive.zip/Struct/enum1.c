#include <stdio.h>


struct Person{
    char name[10];
    enum Rale{shef,matucox,bomj}mart;
    int age;  
};

void function(struct Person msg){
    switch(msg.mart){
        case 0:
            printf("SHEFA");
            break;
        case 1:
            printf("MATUCOXA");
            break;
        case 2:
            printf("BOMJA");
            break;
    };
}


int main(){

    struct Person mart = {
        "Hopar",
        0,
        65
    };
    function(mart);

}