
#include <stdio.h> 
#include <string.h> 

struct name{
    /* data */
    char first[20];
    char last[20];
};
struct bem{
    /* data */
    int limbs;
    struct name title; 
    char type[30];
};

int main(){

struct bem anun;
struct bem *pb;
pb = &anun;
scanf("%d",&pb -> limbs);
strcpy(pb -> type , "Hellow");
printf("Type: %s\n", pb->type);

// struct bem deb ={
//     /* data */
//     6,
//     {"Berbnazel", "Gwolkapwolk"},
//      "Arcturan"
// };
// pb =  &deb;

// printf ("%d\n", deb.limbs); 
// printf("%s\n", pb -> type); 
// printf("%s\n", pb -> type + 2);


}
