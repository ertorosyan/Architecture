#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>

void MyAlarm(int n){
        //printf("\a");
    system("afplay wa.wav");
    
}
void MySigint(){
    printf("Exit work\n");
    exit(EXIT_SUCCESS);
}

int main(){
    signal(SIGALRM, MyAlarm);
    int n;

    do{
        printf("Enter second or exit enter number( n < 0)");
        scanf("%d",&n);
        if(n > 0){
            alarm(n);
        }else if(n < 0)
            MySigint();

    } while (1);
    
}
