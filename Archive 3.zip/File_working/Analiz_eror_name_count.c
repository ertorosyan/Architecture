#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <limits.h>
// #define MAXLINE 5000

typedef struct log
{
    char level[20];
    char msg[100];
}log;

char * most_frencued_msg(char * str,int *max){
    FILE *input = fopen("logfilee.txt", "r");
    char buf[LINE_MAX];
    int most_fr = 1;
    char *msg = malloc(200);
    int count_str = 0;

    while (fgets(buf,sizeof(buf),input))
    {
        int i = 0;
        while(buf[i++]){
            if(buf[i] == ' '){
                int j = 0;
                i++;
                while (buf[i])
                {
                    msg[j++] = buf[i++];
                }
                msg[j] = '\0';
            }
        }
            if(strcmp(str,msg) == 0){
                most_fr++;
                count_str++;
            }
    }
    printf("Msg = %s Count = %d\n",msg,count_str);
    if(most_fr > *max){
        *max = most_fr;
    }
    return msg;
}


void read_to_fileLine(FILE* input){
    log mihat_struct;
    char buf[LINE_MAX];
    int line = 0;
    int count_warning = 0;
    int count_error = 0;
    int count_info = 0;
    char *str_w = "WARNING";
    char *str_e = "ERROR";
    char *str_i = "INFO";
    char msg[100];
    int max = 0;
    char *max_msg;

    while (fgets(buf,sizeof(buf),input))
    {
        int i = 0;
        int j = 0;
        while (buf[i])
        {
            if(buf[i] != ' ')
                mihat_struct.level[j++] = buf[i++];
            else if(buf[i] == ' ')
            {
                mihat_struct.level[j] = '\0'; 
                i++;
                j = 0;
                while (buf[i])
                {
                    mihat_struct.msg[j++] = buf[i++];
                } 
                mihat_struct.msg[j] = '\0'; 
            }
        }
        // printf("%s\n",mihat_struct.msg);
        max_msg = most_frencued_msg(mihat_struct.msg,&max);
        line++;
        if(strcmp(mihat_struct.level,str_w) == 0)
            count_warning++;
        else if(strcmp(mihat_struct.level,str_e) == 0)
            count_error++;
        else if(strcmp(mihat_struct.level,str_i) == 0)
            count_info++;
    }

    printf("Total number of log entries: %d\n",line);
    printf("Most frequent msg = ''%s'' -- Count = %d\n",max_msg,max);
    printf("Number of ERROR entries: %d\n",count_error);
    printf("Number of WARNING entries: %d\n",count_warning);
    printf("Number of INFO entries: %d\n",count_info);
    free(max_msg);
}

int main(){
    FILE *input = fopen("logfilee.txt", "r");
    read_to_fileLine(input);
}