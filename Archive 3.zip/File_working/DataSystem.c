#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>
#include <fcntl.h>
#include <sys/stat.h>
#define MAXLINE 5000 

typedef struct student {
    char name[50];
    int id;
    float grades; // Store up to 5 grades
}Student;


//menu function

void addstudent(FILE *file){

    Student stud;
    char* new = "\n";
    printf("Enter ID : ");
    scanf("%d", &stud.id);

    printf("Enter name : ");
    scanf("%s",stud.name);

    printf("Enter grade : ");
    scanf("%f",&stud.grades);
    fprintf(file, "%d %s %f %s" , stud.id,stud.name,stud.grades,new);
}

void findStudent(FILE *file){

        printf("Enter Id for find : ");
        char find_id[10];
        scanf("%s",find_id);

        struct stat st;
        if (stat("res.txt",&st) == -1){
            perror("Stat !");
            exit(1);
        }
        int size = st.st_size;

        char *buf = malloc(size+1);
        rewind(file); //position -> 0(start)
        fread(buf,1,size, file);
        char *ret ;
        ret = strstr(buf,find_id);
        if(ret){
            int i = 0;
            while (ret[i] != '\n'){
                printf("%c",ret[i]);
                ++i;
            }
        }else{
            printf("ID not found !! \n");
            free(buf);
            exit(0);
        }
        free(buf);
}

void deleteStudent(FILE *file){ //delete student element
    printf("Enter Id for delete : ");
    char find_id[10];
    scanf("%s",find_id);

    struct stat st;
    if (stat("res.txt",&st) == -1){
        perror("Stat !");
        exit(1);
    }

    int size = st.st_size;
    char *buf = malloc(size+1);
    char *delet_string = malloc(100);
    rewind(file); //position -> 0(start)
    fread(buf,1,size, file);
    char *ret;

    ret = strstr(buf,find_id);  //find delete string
    if(ret != NULL){
        int i = 0;
        while (ret[i] != '\n'){
            delet_string[i] = ret[i];
            ++i;
        }
    }else{
        printf("ID not found !! \n");
        free(buf);
        exit(0);
    }

    rewind(file);
    FILE * tmp = fopen("tmp.txt","w");
    char bufer[1024];
    while (fgets(bufer,sizeof(bufer),file) != NULL){
        if(strstr(bufer,delet_string) == NULL)
            fputs(bufer,tmp);
    }
    
    if(remove("res.txt") != 0){
        perror("remove");
        exit(1);
    }
    if(rename("tmp.txt","res.txt") != 0){
        perror("rename");
        exit(1);
    }
    
    free(delet_string);
    free(buf); 
}

void update_element(FILE *file){
    printf("Enter Id for update : ");
    char find_id[10];
    scanf("%s",find_id);

    FILE * tmp = fopen("tmp.txt","w+");
    char buf_tmp[MAXLINE];

    rewind(file);
    while (fgets(buf_tmp,MAXLINE,file))
    {
        if(strstr(buf_tmp,find_id) == NULL){
            fputs(buf_tmp,tmp);
        }else{
            if(buf_tmp[strlen(find_id)] == ' ')
            {
                addstudent(tmp);
            }
            if(buf_tmp[strlen(find_id)] != ' '){
                fputs(buf_tmp,tmp);
            }
        }       
    }
    if(remove("res.txt") != 0){
        perror("remove");
        exit(1);
    }
    
    if(rename("tmp.txt","res.txt") != 0){
        perror("rename");
        exit(1);
    }

}


void veewall(FILE *file){
    struct stat st;
    if (stat("res.txt",&st) == -1){
        perror("Stat !");
        exit(1);
    }
    int size = st.st_size;
    char *buf = malloc(size+1);
    rewind(file); //position -> 0(start)
    fread(buf,1,size, file);
    printf("%s",buf);
    free(buf);
}

void exit_code(){
    printf("\nThank you good job\n");
    exit(EXIT_SUCCESS);
}

int menu(int num){
    printf("Add a new record - 1\t");
    printf("Search for a record (by ID) - 2\n");
    printf("Update a record - 3\t");
    printf("Delete a record (by ID) - 4\n");
    printf("Veew all file contents - 5\t");
    printf("Exit - 6\n ");
    scanf("%d",&num);
    return num;
}

int main(){

    FILE *ff;
    ff = fopen("res.txt","a+");
    
        int num = menu(num);
        switch (num)
        {
        case 1:
            addstudent(ff);
            break;
        case 2:
            findStudent(ff);
            break;
        case 3:
            update_element(ff);
            break;
        case 4:
            deleteStudent(ff);
            break;
        case 5:
            veewall(ff);
            break;    
        case 6:
            exit_code();
            break;
        }
}