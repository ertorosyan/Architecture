#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>
#include <fcntl.h>
#include <sys/stat.h>
#define MAXLINE 5000

/*
Эта задача включает в себя создание программы, которая сравнивает два текстовых файла
и отображает различия рядом, позволяя пользователям объединять изменения.
Для этого потребуются следующие функции из стандартной библиотеки C:
*/

int countlines(FILE * fp)
{
  int ch=0;
  int lines=0;
  lines++;
  while ((ch = fgetc(fp)) != EOF)
    {
      if (ch == '\n')
    lines++;
    }
  return lines;
}

void asd(FILE* f1){
    FILE* aa;
    aa = f1;
    char buf[MAXLINE];
    printf("%s",fgets(buf,MAXLINE,aa));
}


void cmp_files(FILE *f1,FILE *f2,FILE* tmp){

    FILE *max;
    FILE *min;
    int f1_lines = countlines(f1);
    int f2_lines = countlines(f2);

    // max = fopen("f1.txt","r");
    
    char max_buf[MAXLINE];
    
    char min_buf[MAXLINE];

    // if(!fgets(max_buf,MAXLINE,max)) printf("ddffff");
    if(f1_lines > f2_lines){
        max = f1;
        min = f2;
    }else{
        max = f2;
        min = f1;
    }

        rewind(max);
        rewind(min);

    while (fgets(max_buf,MAXLINE,max) != NULL)
    {
        if (fgets(min_buf,MAXLINE,min) != NULL)
        {
            if (max_buf[strlen(max_buf) - 1] == '\n')
                max_buf[strlen(max_buf) - 1] = '\0';
            if (min_buf[strlen(min_buf) - 1] == '\n')
                min_buf[strlen(min_buf) - 1] = '\0';
            if(strcmp(max_buf,min_buf) == 0){
                fputs(max_buf,tmp);
            }else{
                printf("Chose string\n 1 - %s \t 2- %s\n",max_buf,min_buf);
                int chose;
                scanf("%d",&chose);
                if (chose == 1)
                    fputs(max_buf,tmp);
                else
                    fputs(min_buf,tmp);
            }
        }else
            fputs(max_buf,tmp);
        fputs("\n",tmp);
    }
                                    
}


int main(){
    FILE* f1 = fopen("f1.txt","r");
    FILE* f2 = fopen("f2.txt","r");
    FILE* tmp = fopen("tmp.txt","w");

    cmp_files(f1,f2,tmp);
    // asd(f1);

}