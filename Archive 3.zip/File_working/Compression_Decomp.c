#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>
#include <fcntl.h>
#include <sys/stat.h>
#define MAXLINE 5000


void print_file(FILE* input){
    printf("FILE concepts : ");
    char c = fgetc(input);
    while (c != EOF)
    {
        printf("%c",c);
        c = fgetc(input);
    }
}

void compressor(FILE *input){
    rewind(input);
    char buf[MAXLINE];
    FILE *tmp = fopen("res.txt","w");
    while (fgets(buf,sizeof(buf),input) != NULL)
    {
        int i = 0;
        while (buf[i])
        {
            int count = 1;  
            if(buf[i] == buf[i+1] && buf[i] == buf[i+2] || buf[i] == buf[i+1]){
                fputc(buf[i],tmp);
                while (buf[i] == buf[i+1]){
                    count++;
                    ++i;
                }
                fprintf(tmp,"%d",count);
            }else if(count == 1){ // ete simvolic mi hata woshiban chani
                fprintf(tmp,"%c",buf[i]);
            }
            ++i;
        }
    }
    if(remove("file2.txt") != 0){
        perror("Remove !");
        exit(1);
    }
    if(rename("res.txt","file2.txt") != 0){
        perror("REmove !");
        exit(1);
    }
}

void decompressor(FILE *input){
    rewind(input);
    char buf[MAXLINE];
    FILE * tmp = fopen("tmp.txt","w");

    while (fgets(buf,sizeof(buf),input))
    {
        int i = 0;
        while (buf[i])
        {
            if(buf[i] >= '1' && buf[i] <= '9'){
                int count = atoi(&buf[i])-1;
                while (count)
                {
                    fputc(buf[i-1],tmp);
                    --count;
                }
            }else{
                putc(buf[i],tmp);
            }
            i++;
        }
    }
    if(remove("file2.txt") != 0){
        perror("Remove !");
        exit(1);
    }
    if(rename("tmp.txt","file2.txt") != 0){
        perror("Rename !");
        exit(1);
    }
    // fclose(tmp);
}

int main(){
    FILE * input = fopen("file2.txt","r");
    
    print_file(input);
    printf("\nChose (1 & 2)\n Compressor - 1 \t DeCompressor - 2\n");
    int chose;
    scanf("%d",&chose);
    if(chose == 1)
        compressor(input);
    else
        decompressor(input);

    fclose(input);
}