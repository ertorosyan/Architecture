#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define BUFFER_SIZE 1024

void execute_and_write_to_file(const char *command, FILE *file) {
    char buffer[BUFFER_SIZE];
    FILE *pipe = popen(command, "r");
    if (!pipe) {
        fprintf(stderr, "popen() failed\n");
        return;
    }

    // Write the command itself to the file
    fprintf(file, "Command: %s\n", command);

    // Write the output of the command to the file
    while (fgets(buffer, BUFFER_SIZE, pipe) != NULL) {
        fprintf(file, "%s", buffer);
    }

    pclose(pipe);
}

int main() {
    char *uxarkac_hraman = (char *)malloc(BUFFER_SIZE);
    FILE *input = fopen("minishel.txt", "w");

    if (!uxarkac_hraman || !input) {
        fprintf(stderr, "Memory allocation or file opening failed\n");
        return 1;
    }

    while (1) {
        printf("Enter valid command: ");
        //scand-i codna

        if (strcmp(uxarkac_hraman, "break") == 0) {
            break;
        }
        // Use command -v to check if the command exists
        char check_command[BUFFER_SIZE];
        snprintf(check_command, BUFFER_SIZE, "command -v %s > /dev/null 2>&1", uxarkac_hraman);

        if (system(check_command) == 0) {
            // Execute the command and write its output to the file
            execute_and_write_to_file(uxarkac_hraman, input);
        } else {
            fprintf(stderr, "Command not found: %s\n", uxarkac_hraman);
            fprintf(input, "Invalid command: %s\n", uxarkac_hraman);  // Log invalid commands
        }
    }

    free(uxarkac_hraman);
    fclose(input);

    // Reopen the file for reading and display its content
    input = fopen("minishel.txt", "r");
    if (input == NULL) {
        fprintf(stderr, "Failed to open file for reading\n");
        return 1;
    }

    printf("\nCommands entered and their outputs:\n");
    char line[BUFFER_SIZE];
    while (fgets(line, sizeof(line), input) != NULL) {
        printf("%s", line);
    }

    fclose(input);

    return 0;
}
