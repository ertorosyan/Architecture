/*
Simple Text Analyzer
 ~ Task: Create a program that reads a text file and calculates:
    * The total number of words
    * The total number of characters
    * The frequency of each word (a simple word count)
    * The most frequent words
 ~ Variations
    * Have the program display a visual representation of word frequencies (basic bar chart).
    * Allow for text file input from the user.
    * Implement more advanced analysis like identifying the average sentence length.
*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <string.h>


// word frequencie 
void tpel(char** bar_arr, int* count, int bar_count , int fd_res) {
    for (int i = 0; i < bar_count; i++) {
        if (bar_arr[i] != NULL) {
            for (int j = 0; j < bar_count; j++) {
                if (i != j && bar_arr[j] != NULL) {
                    if (strcmp(bar_arr[i], bar_arr[j]) == 0) {
                        count[i]++;
                        count[j] = 0;
                        free(bar_arr[j]);
                        bar_arr[j] = NULL;
                    }
                }
            }
        }
    }
    // max frequencie word in file
    int max = count[0];
    for (int i = 1; i < bar_count; i++) {
        if(max < count[i])
            max = count[i];
    }
    dprintf(fd_res,"Max word = %d\n",max);
    // print & free
    for (int i = 0; i < bar_count; i++) {
        if (bar_arr[i] != NULL) {
            dprintf(fd_res,"Bar '%s' - %d hat \n", bar_arr[i], count[i]);
            free(bar_arr[i]);
        }
    }
    free(bar_arr);
    free(count);
}

void word_frequencie(char* str, int size_symvol , int fd_res) {
    char buf[size_symvol];
    int index = 0;
    int bar_count = 0;
    char** bar_arr = malloc(sizeof(char*));

    for (int i = 0, index_buf = 0; i < size_symvol; i++) {
        if (str[i] != ' ') {
            buf[index_buf++] = str[i];
        }
        if (str[i] == ' ' || i == size_symvol - 1) {
            buf[index_buf] = '\0';
            if (index > 0) {
                bar_arr = realloc(bar_arr, (index + 1) * sizeof(char*));
            }
            bar_arr[index] = malloc((index_buf + 1) * sizeof(char));
            strcpy(bar_arr[index], buf);
            index++;
            index_buf = 0;
            bar_count++;
        }
    }

    int* count = malloc(bar_count * sizeof(int));
    for (int i = 0; i < bar_count; ++i) {
        count[i] = 1;
    }
    //printf("\nWord count = %d\n", bar_count);
    dprintf(fd_res,"Word count = %d\n", bar_count);
    tpel(bar_arr, count, bar_count,fd_res);

}


int main(){
    // open file's
    int fd = open("file2.txt",O_RDONLY);
    if(fd == -1){
        perror("File open !!!");
        exit(EXIT_FAILURE);
    }
    int fd_res = open("res.txt",O_WRONLY | O_TRUNC);
    if(fd_res == -1){
        perror("File open !!!");
        exit(EXIT_FAILURE);
    }
    // get size in file
    struct stat st;
    if(stat("file2.txt",&st) == -1){
        perror("stat !!!");
    }

    dprintf(fd_res,"Simvol count = %lld\n",st.st_size);

    char buf[st.st_size];
    //read file
    if(read(fd,buf,st.st_size) == -1){
        perror("read !!!");
    }
    buf[st.st_size] = '\n';

    word_frequencie(buf,st.st_size,fd_res);
    // close file's
    if(close(fd) == -1){
        perror("Close fd !!!");
    }
    if(close(fd_res) == -1){
        perror("Close fd_res !!!");
    }
}