#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <limits.h>
#include <dirent.h>
#include <pwd.h>
#include <grp.h>
#include <time.h>

char print_mod(mode_t mod){
    if (S_ISREG(mod)) return '-';
    if (S_ISDIR(mod)) return 'd';
    if (S_ISCHR(mod)) return 'c';
    if (S_ISBLK(mod)) return 'b';
    if (S_ISLNK(mod)) return 'l';
    if (S_ISFIFO(mod)) return 'p';
    if (S_ISSOCK(mod)) return 's';
    return '?';
}

void print_permission(mode_t mod){
    char perm[10] = "---------";
    if(mod & S_IRUSR) perm[0] = 'r';
    if(mod & S_IWUSR) perm[1] = 'w';
    if(mod & S_IXUSR) perm[2] = 'x';
    if(mod & S_IRGRP) perm[3] = 'r';
    if(mod & S_IWGRP) perm[4] = 'w';
    if(mod & S_IXGRP) perm[5] = 'x';
    if(mod & S_IRGRP) perm[6] = 'r';
    if(mod & S_IWGRP) perm[7] = 'w';
    if(mod & S_IXGRP) perm[8] = 'x';

    printf("%s",perm);
}

int main(){
    struct dirent *entry;
    struct passwd *pwd;
    struct group *grp;
    struct stat file_stat;
    DIR * dr ;
    char date[20];
    char curent_dir[200];


    //get current pathname
    if(getcwd(curent_dir,sizeof(curent_dir)) == NULL){
        perror("Getcwd !!");
        exit(1);
    }

    // open current directory
    dr = opendir(curent_dir);
    if(dr == NULL){
        perror("opendir !!!");
        exit(1);
    }

    while ((entry = readdir(dr)) != NULL)
    {
        if(stat(entry->d_name,&file_stat) == -1){
            perror("stat !!!");
            exit(1);
        }
        //print file type
        printf("%c",print_mod(file_stat.st_mode));
        //print permission
        print_permission(file_stat.st_mode);
        // print count links in file
        printf(" %hu",file_stat.st_nlink);
    

        // get userID or userName
        pwd = getpwuid(file_stat.st_uid);
        if(pwd == NULL)
            printf(" %u", file_stat.st_uid);
        else   
            printf(" %s", pwd->pw_name);
        
        // get GroupId or GroupName
        grp = getgrgid(file_stat.st_gid);
        if(grp == NULL)
            printf(" %u", file_stat.st_gid);
        else   
            printf(" %s", grp->gr_name);

        // file size
        printf(" %lld",file_stat.st_size);

        // print last time
        strftime(date, sizeof(date), "%b %d %H:%M", localtime(&file_stat.st_mtime));
        printf(" %s", date);

        // print name
        printf(" %s\n",entry->d_name);
    }
    closedir(dr);
}