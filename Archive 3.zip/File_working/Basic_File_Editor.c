/*
Задача 2: Базовый редактор файлов:
Задача: Создайте программу, выполняющую роль простого текстового редактора.
 Должно.
Откройте «my_info.txt» (или файл по вашему выбору).
Прочитайте и отобразите содержимое.
Позвольте пользователю редактировать текст.
Запишите изменения обратно в файл.
Проблемы:
Как вы будете справляться с перезаписью по сравнению с добавление?
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <string.h>
#include <unistd.h>

int main(){

    int fd = open("file2.txt",O_RDWR );
    if (fd == -1)
      perror("Error open fd1");
    
    struct stat st;
    if(stat("file2.txt",&st) == -1)
        perror("Error stat");

    int size = st.st_size;
    char print_buf[size];
    char buf[20];
    int flag = 0;

    
        read(fd,print_buf,size);
        printf("Current text = %s\n",print_buf);
        printf("If you have edit text enter 1 to exit enter 0 : ");
        scanf("%d",&flag);
        if(flag == 0){
            exit(0);
        }else{
            printf("\nEnter string : \n");
            scanf("%s",buf);
            write(fd,buf,strlen(buf));
            // fdatasync(fd);

            if(stat("file2.txt",&st) == -1)
                perror("Error stat");
            size = st.st_size;
            char print_buf1[size];
            lseek(fd,0,SEEK_SET);
            read(fd,print_buf1,size);
            printf("end text = %s",print_buf1);
        }


}