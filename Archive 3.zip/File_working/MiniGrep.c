
/*
Мини-греп
Напишите программу на языке C, имитирующую базовую функциональность утилиты командной строки grep.
 Ваша программа должна принимать два аргумента командной строки: шаблон поиска (строку) и имя файла.
  Затем он должен выполнить поиск по указанному файлу и распечатать все строки, 
  содержащие заданный шаблон поиска.
Ваша программа должна обрабатывать аргументы командной строки,
 используя argc и argv в основной функции.
Вы можете предположить, что указанный файл существует и доступен для чтения.
Ваша программа должна читать файл построчно и искать заданный шаблон в каждой строке.
 Если строка содержит шаблон поиска, ваша программа должна вывести эту строку на стандартный вывод.
По умолчанию ваш поиск должен учитывать регистр, но вы можете указать дополнительный флаг,
 чтобы сделать его нечувствительным к регистру (например, -i или --ignore-case).
*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <string.h>
#include <unistd.h>

void find(char *buf,int size ,char * key,int flag){
    char temp[size];
    int k = 0;
    for (int i = 0; i < size; i++){
        if(buf[i] != '\n'){
            temp[k++] = buf[i];
        }else{
            temp[k] = '\0';
            char *res;
            if(flag == 1){
                res = strcasestr(temp,key);
            }else{
                res = strstr(temp,key);
            }
            printf("%s\n",res);
            k = 0;   
        }
    }
}

int main(int arc,char** arg){

    char *key;
    key = arg[1];
    int flag = 0;
    if(arg[3]){
        flag = 1;
    }
    int fd = open(arg[2],O_RDONLY);

    struct stat st;
    if(stat(arg[2],&st) == -1)
        perror("Stat !");
    int size = st.st_size;
    
    char buf[size];
    if(read(fd,buf,size) == -1)
        perror("Read !!!");

    find(buf,size,key,flag);
    
    if(close(fd) == -1){
        perror("Close file");
    }
}