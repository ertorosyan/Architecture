#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define PORT_NUM 9090
#define BUF_SIZE 256
#define FD_COUNT 5

int clients[FD_COUNT];

typedef struct names{
    char name[20];
    int fd;
}names[];

void check(const char* msg){
    perror(msg);
    exit(1);
}

void * handle_client(void * fd){
    int client_fd = *(int*)fd;
    char buf[BUF_SIZE];
    int Rbyte = read(client_fd, buf, BUF_SIZE);
        if (Rbyte < 0){
            printf("wochiban chi kartace clientneric !!!!!!!");
            return NULL;
        }
    printf("Name client %s is a connect # \n",buf);

    while (1){
        memset(buf,0,BUF_SIZE);

        int Rbyte = read(client_fd, buf, BUF_SIZE);
        if (Rbyte < 0){
            printf("wochiban chi kartace clientneric !!!!!!!");
            return NULL;
        }

        buf[Rbyte] = '\0';

        for(int i = 0; i < FD_COUNT; ++i) {
            if(clients[i] != 0 && clients[i] != client_fd) {
                int Wbyte = write(clients[i], buf, strlen(buf));
                    if (Wbyte <= 0){
                        printf("myus clientnerin ban chi uxarkum !!!!!\n");
                        break;                        
                    }
            }
        }
    }
    return NULL;
}


int main(){

    int server = socket(AF_INET,SOCK_STREAM,0);
    if(server < 0)
        check("server() !");
    
    struct sockaddr_in add;
    memset(&add,0,sizeof(add));
    add.sin_family = AF_INET;
    add.sin_addr.s_addr = INADDR_ANY;
    add.sin_port = htons(PORT_NUM);
    socklen_t size = sizeof(add);

    if(bind(server , (struct sockaddr *)&add , sizeof(add)) < 0){
        close(server);
        check("bind() !");
    }

    if(listen(server,5) < 0){
        close(server);
        check("Listen !");
    }

    printf("Server started...\n");
    int i = 0;
    pthread_t proc[3];
    while (1){
        struct sockaddr_in client;
        memset(&client,0,sizeof(client));
        socklen_t size = sizeof(client);

        int newsocet_fd = accept(server,(struct sockaddr *)&client,&size);
        if(newsocet_fd < 0){
            printf("Client don't connect !");
        }

        int * new_sock = malloc(sizeof(int));
        clients[i] = newsocet_fd;    // add accept_fd in array ''clients''
        new_sock = &newsocet_fd;
        if(pthread_create(&proc[i],NULL,handle_client,(void*)new_sock) < 0){
            printf("dont create thread !!!!");
            break;
        }
        i++;
    }
    pthread_join(proc[0],NULL);
    pthread_join(proc[1],NULL);
    pthread_join(proc[2],NULL);
    close(server);
}