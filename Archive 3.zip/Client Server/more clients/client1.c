#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define PORT_NUM 5050
#define BUF_SIZE 256

void check(const char* msg) {
    perror(msg);
    exit(1);
}

void* read_handle(void* fd) {
    int client_fd = *(int*)fd;
    char buf[BUF_SIZE];
    while (1) {
        memset(buf, 0, BUF_SIZE);
        int Rbyte = read(client_fd, buf, BUF_SIZE);
        if (Rbyte <= 0) {
            if (Rbyte == 0) {
                printf("Server disconnected\n");
            } else {
                printf("Error reading from server\n");
            }
            close(client_fd);
            exit(0);
        }
        buf[Rbyte] = '\0';
        printf("%s\n", buf);
    }
    return NULL;
}

void* write_handle(void* fd) {
    int client_fd = *(int*)fd;
    char buf[BUF_SIZE];

    while (1) {
        memset(buf, 0, BUF_SIZE);
        printf("Enter msg: ");
        fgets(buf, BUF_SIZE, stdin);
        buf[strcspn(buf, "\n")] = '\0'; // Remove newline character

        int Wbyte = write(client_fd, buf, strlen(buf));
        if (Wbyte <= 0) {
            printf("Error writing to server\n");
            close(client_fd);
            exit(0);
        }
    }
    return NULL;
}

int main() {
    int client = socket(AF_INET, SOCK_STREAM, 0);
    if (client < 0)
        check("socket()");

    struct sockaddr_in add;
    add.sin_family = AF_INET;
    add.sin_port = htons(PORT_NUM);
    add.sin_addr.s_addr = inet_addr("127.0.0.1");
    socklen_t size = sizeof(add);

    if (connect(client, (struct sockaddr*)&add, size) < 0) {
        close(client);
        check("connect()");
    }

    char buf[BUF_SIZE];
    printf("Enter name: ");
    fgets(buf, BUF_SIZE, stdin);
    buf[strcspn(buf, "\n")] = '\0'; // Remove newline character

    int Wbyte = write(client, buf, strlen(buf));
    if (Wbyte < 0) {
        close(client);
        check("write() msg name");
    }

    pthread_t read_thread, write_thread;

    if (pthread_create(&read_thread, NULL, read_handle, (void*)&client) < 0) {
        close(client);
        check("pthread_create read");
    }

    if (pthread_create(&write_thread, NULL, write_handle, (void*)&client) < 0) {
        close(client);
        check("pthread_create write");
    }

    pthread_join(read_thread, NULL);
    pthread_join(write_thread, NULL);
    close(client);
    return 0;
}
