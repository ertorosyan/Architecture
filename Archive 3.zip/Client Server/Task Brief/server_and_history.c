#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <termios.h>


#define PORT_NUM 8092
#define BUF_SIZE 256
#define BUFFER_SIZE 1024
#define FD_COUNT 5
#define MAX_HISTORY_SIZE 100
#define MAX_COMMAND_LENGTH 256

typedef struct {
    struct sockaddr_in add_client;
    int * client_fd;
}info;

info client_info[5];


void command_execute(char * uxarkac_hraman,void * arg){
    
        int index = *(int*)arg;
        // Use command -v to check if the command exists
        char check_command[BUFFER_SIZE];
        snprintf(check_command, BUFFER_SIZE, "command -v %s > /dev/null 2>&1", uxarkac_hraman);

        if (system(check_command) == 0) {
            // Execute the command and send to child
            char buffer[BUFFER_SIZE];
            FILE *pipe = popen(uxarkac_hraman, "r");  // open pipe to execute command
            if (!pipe) {
                fprintf(stderr, "popen() failed\n");
                return;
            }
            printf("Command: %s\n", uxarkac_hraman);
            // Write the output of the command to the file
            while (fgets(buffer, BUFFER_SIZE, pipe) != NULL) {
                int Wbyte = write(*client_info[index].client_fd,buffer,BUF_SIZE);
                if(Wbyte < 0){
                    perror("Don't send info to client !");
                    return;
                }
            }
            pclose(pipe);

        } else {
            fprintf(stderr, "Command not found: %s\n", uxarkac_hraman);
        }
}


void disable_raw_mode(struct termios *orig_termios) {
    tcsetattr(STDIN_FILENO, TCSAFLUSH, orig_termios);
}

void enable_raw_mode(struct termios *orig_termios) {
    tcgetattr(STDIN_FILENO, orig_termios);
    struct termios raw = *orig_termios;
    raw.c_lflag &= ~(ECHO | ICANON);
    tcsetattr(STDIN_FILENO, TCSAFLUSH, &raw);
}

void load_history(const char *filename, char history[][MAX_COMMAND_LENGTH], int *history_count) {
FILE *file = fopen(filename, "r");
    if (!file) return;

    char line[MAX_COMMAND_LENGTH];
    while (fgets(line, sizeof(line), file) && *history_count < MAX_HISTORY_SIZE) {
        line[strcspn(line, "\n")] = '\0';  
        strcpy(history[(*history_count)++], line);
    }

    fclose(file);
}

void save_history(const char *filename, char history[][MAX_COMMAND_LENGTH], int history_count) {
    FILE *file = fopen(filename, "w");
    if (!file) return;

    for (int i = 0; i < history_count; ++i) {
        fprintf(file, "%s\n", history[i]);
    }

    fclose(file);
}

void* handle_client(void* arg){
    int i = *(int*)arg;
    char buff[BUF_SIZE];
    char ip_buff[BUF_SIZE];

    struct termios orig_termios;
    enable_raw_mode(&orig_termios);

    char history[MAX_HISTORY_SIZE][MAX_COMMAND_LENGTH] = {0};
    int history_count = 0, history_index = -1;

    const char *history_filename = "history.txt";
    load_history(history_filename, history, &history_count);

    char command[MAX_COMMAND_LENGTH] = {0};
    int command_length = 0;

    printf("Command: ");
    fflush(stdout);

    //print client ip
    if(inet_ntop(AF_INET , &(client_info[i].add_client.sin_addr) , ip_buff , BUF_SIZE) != NULL){
        printf("Client IP %s is connected!\n",ip_buff);
    }else{
        perror("inet_ntop() !");
    }

    while (1){
        memset(buff, 0, BUF_SIZE);
        int Rbyte = read(*client_info[i].client_fd, buff, BUF_SIZE);
        if (Rbyte <= 0) {
            if (Rbyte == 0) {
                printf("Client disconnected.\n");
            } else {
                perror("read()");
            }
            close(*client_info[i].client_fd);
            free(client_info[i].client_fd);
            free(arg);
            disable_raw_mode(&orig_termios);
            return NULL;
        }

        // Сохранение команды в истории
        if (Rbyte > 0) {
            strcpy(history[history_count++], buff);
            save_history(history_filename, history, history_count);
        }

        // Ввод с клавиатуры для истории команд
        char c = '\0';
        read(STDIN_FILENO, &c, 1);

        if (c == 27) {
            char seq[2];
            read(STDIN_FILENO, seq, 2);
            if (seq[0] == '[') {
                if (seq[1] == 'A') {
                    // Up arrow
                    if (history_index + 1 < history_count) {
                        history_index++;
                        strcpy(command, history[history_count - 1 - history_index]);
                        command_length = strlen(command);
                        printf("\rCommand: %s", command);
                        fflush(stdout);
                    }
                } else if (seq[1] == 'B') {
                    // Down arrow
                    if (history_index >= 0) {
                        history_index--;
                        if (history_index >= 0) {
                            strcpy(command, history[history_count - 1 - history_index]);
                        } else {
                            command[0] = '\0';
                        }
                        command_length = strlen(command);
                        printf("\rCommand: %s", command);
                        fflush(stdout);
                    }
                }
            }
        } else if (c == '\n') {
            if (command_length > 0) {
                printf("\nYou entered: %s\n", command);
                strcpy(history[history_count++], command);
                save_history(history_filename, history, history_count);
            }
            printf("Command: ");
            fflush(stdout);
            command[0] = '\0';
            command_length = 0;
            history_index = -1;
        } else {
            if (command_length < MAX_COMMAND_LENGTH - 1) {
                command[command_length++] = c;
                command[command_length] = '\0';
            }
            fflush(stdout);
        }

        // Execute command received from client
        command_execute(buff, arg);
    }

    disable_raw_mode(&orig_termios);
    return NULL;
}



int main(){
    int server = socket(AF_INET,SOCK_STREAM,0);
    if(server < 0){
        perror("sock() !");
        exit(1);
    }

    struct sockaddr_in add_server;
    memset(&add_server,0,sizeof(add_server));
    add_server.sin_family = AF_INET;
    add_server.sin_port = htons(PORT_NUM);
    add_server.sin_addr.s_addr = INADDR_ANY;

    if(bind(server,(struct sockaddr*)&add_server,sizeof(add_server)) < 0 ){
        perror("bind() !");
        close(server);
        exit(1);
    }

    if(listen(server,5) < 0){
        perror("listen() !");
        close(server);
        exit(1);
    }
    printf("Server started...\n");

    pthread_t proc[5];
    int i = 0;
    while (1){
        memset(&client_info[i].add_client,0,sizeof(client_info[i].add_client));
        socklen_t size = sizeof(client_info[i].add_client);
        
        client_info[i].client_fd = malloc(sizeof(int));
        if (!client_info[i].client_fd) {
            perror("malloc()");
            close(server);
            exit(1);
        }

        *client_info[i].client_fd = accept(server , (struct sockaddr*)&client_info[i].add_client , &size);
        if(*client_info[i].client_fd < 0){
            perror("accept() !");
            close(server);
            free(client_info[i].client_fd);
            exit(1);
        }
        // argument to thread
        int *arg = malloc(sizeof(*arg));
        if (!arg) {
            perror("malloc()");
            close(*client_info[i].client_fd);
            free(client_info[i].client_fd);
            close(server);
            exit(1);
        }
        *arg = i;
        if(pthread_create(&proc[i] , NULL , handle_client , arg ) < 0){
            perror("Don't create thread !");
            close(server);
            free(client_info[i].client_fd);
            exit(1);
        }
        pthread_detach(proc[i]);
        ++i;
    }
}