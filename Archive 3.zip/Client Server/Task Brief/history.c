#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <termios.h>

#define PORT_NUM 8092
#define BUF_SIZE 256
#define MAX_HISTORY_SIZE 100
#define MAX_COMMAND_LENGTH 256

void disable_raw_mode(struct termios *orig_termios) {
    tcsetattr(STDIN_FILENO, TCSAFLUSH, orig_termios);
}

void enable_raw_mode(struct termios *orig_termios) {
    tcgetattr(STDIN_FILENO, orig_termios);
    struct termios raw = *orig_termios;
    raw.c_lflag &= ~(ECHO | ICANON);
    raw.c_cc[VMIN] = 1;
    raw.c_cc[VTIME] = 0;
    tcsetattr(STDIN_FILENO, TCSAFLUSH, &raw);
}

void load_history(const char *filename, char history[][MAX_COMMAND_LENGTH], int *history_count) {
    FILE *file = fopen(filename, "r");
    if (!file) return;

    char line[MAX_COMMAND_LENGTH];
    while (fgets(line, sizeof(line), file) && *history_count < MAX_HISTORY_SIZE) {
        line[strcspn(line, "\n")] = '\0';
        strcpy(history[(*history_count)++], line);
    }

    fclose(file);
}

void save_history(const char *filename, char history[][MAX_COMMAND_LENGTH], int history_count) {
    FILE *file = fopen(filename, "w");
    if (!file) return;

    for (int i = 0; i < history_count; ++i) {
        fprintf(file, "%s\n", history[i]);
    }

    fclose(file);
}

int main() {
    int sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) {
        perror("socket()");
        exit(1);
    }

    struct sockaddr_in server_addr;
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT_NUM);
    server_addr.sin_addr.s_addr = inet_addr("127.0.0.1");

    if (connect(sock, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("connect()");
        close(sock);
        exit(1);
    }

    struct termios orig_termios;
    enable_raw_mode(&orig_termios);

    char history[MAX_HISTORY_SIZE][MAX_COMMAND_LENGTH] = {0};
    int history_count = 0, history_index = -1;

    const char *history_filename = "client_history.txt";
    load_history(history_filename, history, &history_count);

    char command[MAX_COMMAND_LENGTH] = {0};
    int command_length = 0;

    printf("Enter command: ");
    fflush(stdout);

    while (1) {
        char c = '\0';
        read(STDIN_FILENO, &c, 1);

        if (c == 27) {
            char seq[2];
            read(STDIN_FILENO, seq, 2);
            if (seq[0] == '[') {
                if (seq[1] == 'A') {
                    // Up arrow
                    if (history_index + 1 < history_count) {
                        history_index++;
                        strcpy(command, history[history_count - 1 - history_index]);
                        command_length = strlen(command);
                        printf("\rEnter command: %s", command);
                        fflush(stdout);
                    }
                } else if (seq[1] == 'B') {
                    // Down arrow
                    if (history_index >= 0) {
                        history_index--;
                        if (history_index >= 0) {
                            strcpy(command, history[history_count - 1 - history_index]);
                        } else {
                            command[0] = '\0';
                        }
                        command_length = strlen(command);
                        printf("\rEnter command: %s", command);
                        fflush(stdout);
                    }
                }
            }
        } else if (c == '\n') {
            if (command_length > 0) {
                printf("\nYou entered: %s\n", command);
                strcpy(history[history_count++], command);
                save_history(history_filename, history, history_count);

                if (send(sock, command, strlen(command), 0) < 0) {
                    perror("send()");
                    close(sock);
                    disable_raw_mode(&orig_termios);
                    exit(1);
                }

                char response[BUF_SIZE];
                int bytes_received = recv(sock, response, BUF_SIZE, 0);
                if (bytes_received < 0) {
                    perror("recv()");
                    close(sock);
                    disable_raw_mode(&orig_termios);
                    exit(1);
                }

                response[bytes_received] = '\0';
                printf("Response from server: %s\n", response);
            }
            printf("Enter command: ");
            fflush(stdout);
            command[0] = '\0';
            command_length = 0;
            history_index = -1;
        } else {
            if (command_length < MAX_COMMAND_LENGTH - 1) {
                command[command_length++] = c;
                command[command_length] = '\0';
            }
            printf("\rEnter command: %s", command);
            fflush(stdout);
        }
    }

    disable_raw_mode(&orig_termios);
    close(sock);
    return 0;
}
