#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <sys/socket.h>
#include <netinet/in.h>


#define PORT_NUM 8092
#define BUF_SIZE 256

void* read_handle(void* fd) {
    int client_fd = *(int*)fd;
    char buf[BUF_SIZE];
    while (1) {
        memset(buf, 0, BUF_SIZE);
        int Rbyte = read(client_fd, buf, BUF_SIZE);
        if (Rbyte <= 0) {
            if (Rbyte == 0)
                printf("Server disconnected !\n");
            else
                printf("Error reading from server\n"); 
            close(client_fd);
            pthread_exit(NULL);
            break;
        }
        buf[Rbyte] = '\0';
        printf("%s\n", buf);
    }
    return NULL;
}


void* write_handle(void* fd) {
    int client_fd = *(int*)fd;
    char buf[BUF_SIZE];

    while (1) {
        memset(buf, 0, BUF_SIZE);
        printf("\nEnter command: ");
        fgets(buf, BUF_SIZE, stdin);
        buf[strcspn(buf, "\n")] = '\0'; // Remove newline character

        int Wbyte = write(client_fd, buf, strlen(buf));
        if (Wbyte <= 0) {
            printf("Error writing to server\n");
            close(client_fd);
            pthread_exit(NULL); 
        }
    }
    return NULL;
}


int main(){

    int client = socket(AF_INET,SOCK_STREAM,0);
    if(client < 0){
        perror("socket !");
        exit(1);
    }

    struct sockaddr_in client_add;
    client_add.sin_family = AF_INET;
    client_add.sin_port = htons(PORT_NUM);
    client_add.sin_addr.s_addr = inet_addr("127.0.0.1"); //server IP

    if (connect(client, (struct sockaddr*)&client_add, sizeof(client_add)) < 0) {
        perror("connect() !");
        close(client);
    }

    pthread_t read_thread, write_thread;

    if (pthread_create(&write_thread, NULL, write_handle, (void*)&client) < 0) {
        perror("thread don't create !");
        close(client);
        exit(1);
    }
     if (pthread_create(&read_thread, NULL, read_handle, (void*)&client) < 0) {
        perror("thread don't create !");
        close(client);
        exit(1);
    }

    pthread_join(write_thread, NULL);
    pthread_join(read_thread, NULL);
    close(client);
    return 0;
}