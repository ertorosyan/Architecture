#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>

void signall(char tar , int pid){
    int i = 0;
    while(i != 8){
        printf("%c",(tar >> i) & 1);
        if( ((tar >> i) & 1)  == 1){
            kill(pid,SIGUSR1);
        }else{
            kill(pid,SIGUSR2);
        }
        usleep(50);
        ++i;
    }
}

void str_to_simvols(char * str,int pid){
    if(str == NULL){
        printf("Not string !");
        exit(EXIT_FAILURE);
    }
    char tar;
    for(int i = 0 ; str[i] ; ++i ){
        tar = str[i];
        signall(tar,pid);
    }
   
}


int main(int argc,char* argv[]){
    
    int pid = atoi(argv[1]);
    char str[20];
    
    printf("Enter string : ");
    scanf("%s",str);
    str_to_simvols(str,pid);
    
    
}