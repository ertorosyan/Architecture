#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>

char sm = 0;
static int i = 0;

void sig_hend(int signum) {
    sm |= (1 << i);
    ++i;
    if (i == 8) {
        dprintf(1,"%c",sm);
        i = 0;
        sm = 0;
    } 
}

void sig_hend0(int signum) {
    ++i;
    if (i == 8) {
        dprintf(1,"%c",sm);
        i = 0;
        sm = 0;
    }
}
void sig_hend_int(int signum){
    printf("\nThenk you\n");
    exit(EXIT_SUCCESS);
}


int main() {
    printf("%d\n", getpid());
    if (signal(SIGUSR1, sig_hend) == SIG_ERR ||
        signal(SIGUSR2, sig_hend0) == SIG_ERR || signal(SIGINT,sig_hend_int) == SIG_ERR) {
        perror("signal");
        return EXIT_FAILURE;
    }
    while (1) {}
    return EXIT_SUCCESS;
}
