#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/wait.h>

#define MULTICAST_GROUP "239.0.0.1"
#define MULTICAST_PORT 12345
#define BUF_SIZE 512

void sender(int sockfd, struct sockaddr_in *multicast_addr) {
    char buffer[BUF_SIZE];
    while (1) {
        printf("Enter message: ");
        fgets(buffer, BUF_SIZE, stdin);
        if (sendto(sockfd, buffer, strlen(buffer), 0, (struct sockaddr*)multicast_addr, sizeof(*multicast_addr)) < 0) {
            perror("sendto");
            exit(EXIT_FAILURE);
        }
    }
}

void receiver(int sockfd) {
    struct sockaddr_in local_addr, multicast_addr;
    struct ip_mreqn mreqn;
    char buffer[BUF_SIZE];

    // Настройка локального адреса
    memset(&local_addr, 0, sizeof(local_addr));
    local_addr.sin_family = AF_INET;
    local_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    local_addr.sin_port = htons(MULTICAST_PORT);

    // Привязка сокета к локальному адресу
    if (bind(sockfd, (struct sockaddr *)&local_addr, sizeof(local_addr)) < 0) {
        perror("bind");
        close(sockfd);
        exit(EXIT_FAILURE);
    }

    // Присоединение к мультикаст-группе
    memset(&mreqn, 0, sizeof(mreqn));
    mreqn.imr_multiaddr.s_addr = inet_addr(MULTICAST_GROUP);
    mreqn.imr_address.s_addr = htonl(INADDR_ANY);
    mreqn.imr_ifindex = 0; // Используем интерфейс по умолчанию

    if (setsockopt(sockfd, IPPROTO_IP, IP_ADD_MEMBERSHIP, &mreqn, sizeof(mreqn)) < 0) {
        perror("setsockopt IP_ADD_MEMBERSHIP");
        close(sockfd);
        exit(EXIT_FAILURE);
    }

    // Получение сообщений от мультикаст-группы
    socklen_t addrlen = sizeof(multicast_addr);
    while (1) {
        memset(buffer, 0, BUF_SIZE);
        if (recvfrom(sockfd, buffer, BUF_SIZE, 0, (struct sockaddr *)&multicast_addr, &addrlen) < 0) {
            perror("recvfrom");
            close(sockfd);
            exit(EXIT_FAILURE);
        }
        printf("Received message: %s\n", buffer);
    }
}

int main() {
    int sockfd;
    struct sockaddr_in multicast_addr;

    // Создание UDP сокета
    if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
        perror("socket");
        exit(EXIT_FAILURE);
    }

    // Настройка структуры адреса для мультикаста
    memset(&multicast_addr, 0, sizeof(multicast_addr));
    multicast_addr.sin_family = AF_INET;
    multicast_addr.sin_addr.s_addr = inet_addr(MULTICAST_GROUP);
    multicast_addr.sin_port = htons(MULTICAST_PORT);

    pid_t proc = fork();
    if (proc < 0) {
        perror("fork");
        exit(EXIT_FAILURE);
    } else if (proc == 0) {
        // Дочерний процесс: отправка сообщений
        sender(sockfd, &multicast_addr);
    } else {
        // Родительский процесс: получение сообщений
        receiver(sockfd);
        wait(NULL);
    }

    close(sockfd);
    return 0;
}
