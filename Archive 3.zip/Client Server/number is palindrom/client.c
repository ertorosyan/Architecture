#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define BUF_SIZE 256
#define PORT 8080

void check(const char * msg){
	perror(msg);
    exit(1);
}


int main(){
	int client_fd = socket(AF_INET,SOCK_STREAM,0);
	if(client_fd < 0)
		check("Socket() !");
	
	struct sockaddr_in add;
	add.sin_family = AF_INET;
	add.sin_port = htons(PORT);
	add.sin_addr.s_addr = inet_addr("127.0.0.1");

	socklen_t size = sizeof(add);
	if(connect(client_fd,(struct sockaddr *)&add,size) < 0 ){
		close(client_fd);
		check("conect() !");
	}

	char num;
	printf("Enter number :");
	scanf("%s",&num);

	int Wbyte = write(client_fd,&num,1);
	if(Wbyte < 1){
		close(client_fd);
		check("write() !");
	}

	char buf[BUF_SIZE];
	int Rbyte = read(client_fd,buf,BUF_SIZE);
	if(Rbyte < 0){
		close(client_fd);
		check("read() !");
	}

	printf("Result : %s",buf);
	close(client_fd);
}