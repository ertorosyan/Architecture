#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define PORT_NUM 8080
#define BUF_SIZE 256

void check(const char* msg){
    perror(msg);
    exit(1);
}


int number_is_palindrome(const char* num){

    int len = strlen(num);
    ////    ????????????
    // if(len == 1)
    //     return 0;

    int i = 0;
    int j = len -1;

    while (i <= j){
        if (num[i] != num[j])
            return -1;
        i++;
        j--;
    }
    return 0;
}



int main(){

    int server = socket(AF_INET,SOCK_STREAM,0);
    if(server == -1)    
        check("Socket !");

    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(PORT_NUM);
    addr.sin_addr.s_addr = INADDR_ANY;

    if(bind(server, (struct sockaddr*)&addr, sizeof(addr)) < 0 ){
        close(server);
        check("Bind !");
    }
    
    if(listen(server,5) < 0){
        close(server);
        check("Listen !");
    }

    struct sockaddr_in client;
    memset(&client,0,sizeof(client));
    socklen_t size = sizeof(client);

    printf("Server is listening...\n");

    int server_fd = accept(server,(struct sockaddr*)&client, &size);
    if(server_fd < 0){
        close(server);
        check("Accept !!!");
    }   

    printf("Client is connected !\n");

    //read from socket
    char buffer[BUF_SIZE] = {0};
    int Rbyte = read(server_fd, buffer, BUF_SIZE -1);
    if (Rbyte < 0) {
        close(server_fd);
        close(server);
        check("Read");
    }

    buffer[Rbyte] = '\n';

    // check for number is palindrom or not
    char *res_msg_palindrome = "Number is Palindrom\n";
    char *res_msg_is_not_palindrome = "Number is't Palindrom\n";

    int res = number_is_palindrome(buffer);

    const char *response = (res == 0) ? res_msg_palindrome : res_msg_is_not_palindrome;
    int Rwrite = write(server_fd, response, strlen(response));
    if (Rwrite < 0) {
        close(server_fd);
        close(server);
        check("Write");
    }

    close(server_fd);
    close(server);
    
}