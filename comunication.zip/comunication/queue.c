#include "queue.h"

void* print(void* arg){
    static int i = 0;
    printf("%d\n",i++);
    return NULL;
}

void* print2(void* arg){
    static int i = 10;
    printf("%d\n",i++);
    return NULL;
}

void constructor(queue_t* obj){
    obj->head = NULL;
    printf("Queue is alocate  \n");
    pthread_mutex_init(&obj->lock, NULL);
}

task_t pop_front(queue_t* obj){
    
    pthread_mutex_lock(&obj->lock);
    task_t ret_task;
    if(obj->head == NULL || obj == NULL){
        printf("invalid list !!\n");
        pthread_mutex_unlock(&obj->lock);
        pthread_exit(0);
    }else{
        ret_task = obj->head->task;
        struct node_t *tmp = obj->head->next;
        free(obj->head);
        obj->head = tmp;
        pthread_mutex_unlock(&obj->lock);
    }
    return ret_task;
}

void push_back(queue_t* obj,task_t task){

    pthread_mutex_lock(&obj->lock);
    struct node_t * new_list = malloc(sizeof(struct node_t));
    new_list->next = NULL;
    new_list->task = task;

    if(obj->head == NULL){
        obj->head = new_list;
        pthread_mutex_unlock(&obj->lock);
    }else{
        struct node_t *tmp = obj->head;
        while (tmp->next)
            tmp = tmp->next;             
        tmp->next = new_list;
    }
    pthread_mutex_unlock(&obj->lock);
}


void *th_func(void* arg){
    queue_t *obj = (queue_t *)arg;
    while (obj->head)
    {
        task_t task = pop_front(obj);
        task.current_job(task.arg);
    }
    return NULL;
}

// int main(){

//      task_t task1 = {print,NULL};
//      task_t task2 = {print2,NULL};
//      task_t task3 = {print,NULL};
//      task_t task4 = {print2,NULL};

//     queue_t obj;
//     constructor(&obj);
//     push_back(&obj,task1);
//     push_back(&obj,task2);
//     push_back(&obj,task3);
//     push_back(&obj,task4);
//     push_back(&obj,task1);
//     push_back(&obj,task2);
//     push_back(&obj,task3);
//     push_back(&obj,task4);

//     pthread_t th[3];

//     for(int i = 0; i < 3; i++)
//         pthread_create(&th[i],NULL,th_func,(void*)&obj);

//     for (int i = 0; i < 3; i++)
//         pthread_join(th[i],NULL);
// }