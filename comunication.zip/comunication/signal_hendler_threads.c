#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>
#include <pthread.h>
    pthread_t th[3];

void siguser1_hend(int signum){

    if(pthread_self() == th[0]){
        printf("I'm thread 1\n");
        return;
    }
    else if(pthread_self() == th[1])
        printf("I'm thread 2\n");
    else if(pthread_self() == th[2])
        printf("Good bye\n");
}

void * thread_func(void* arg){
    pthread_kill(pthread_self(),SIGUSR1);

    return NULL;
}

int main(){
    signal(SIGUSR1,siguser1_hend);

    
    for (int i = 0; i < 3; i++)
    {
        pthread_create(&th[i],NULL,thread_func,NULL);
    }

    for (int i = 0; i < 3; i++)
    {
        pthread_join(th[i],NULL);
    }
    
}