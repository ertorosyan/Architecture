#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <sys/mman.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#define PTHREAD_COUNT 3
#define MAX_LINE 500


pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

struct argument{
    FILE* input;
    char *add;
}typedef Argument;


void * read_in_data(void* arg){
    Argument * obj = (Argument*)arg;
    char buf[MAX_LINE];
    while (fgets(buf,sizeof(buf),obj->input) != NULL)
    {
        pthread_mutex_lock(&mutex);   
        strcat(obj->add,buf);
        pthread_mutex_unlock(&mutex);
    }
    
    return NULL;
}


void * read_data(void* arg){
    Argument * obj = (Argument*)arg;
    int*  ret = calloc(sizeof(int) , 100);

    char buf[MAX_LINE];
    for (int i = 0; obj->add[i]; ++ i)
    {
        int num = 0;
        while (obj->add[i] && obj->add[i] != '\n')
        {
            num *= 10;
            num += obj->add[i] + '0';
            i++;
        }
        ret[num] += 1;
    }
    return (void*)ret;
}

void file_open_add_randDigit(Argument* obj){
    obj->input = fopen("data.txt","w+");
    if(obj->input == NULL){
        perror("FIle open !");
        exit(0);
    }
    // random digits puts in  shared memory
    for (int i = 1; i <= 100; i++){
        fprintf(obj->input, "%d\n", rand() % (50 + 1));
    }

}

int main(){
    Argument* obj = (Argument*)malloc(sizeof(Argument));

    key_t key = ftok("file.txt",7);
    if(key == -1){
        perror("Ftok !!!");
        exit(0);
    }
    int shmid = shmget(key,4096,IPC_CREAT | 0666);
    obj->add = shmat(shmid,NULL,0);

    int * res;
    memset(obj->add,0,4096);
    file_open_add_randDigit(obj);

    fflush(obj->input);
    rewind(obj->input);

    // 1-3-th threads
    pthread_t th[PTHREAD_COUNT];
    for (int i = 0; i < PTHREAD_COUNT; i++)
    {
        pthread_create(&th[i],NULL,read_in_data,obj);
    }

    for (int i = 0; i < PTHREAD_COUNT; i++)
    {
        pthread_join(th[i],NULL);
    }

    // 4-th thread    
    pthread_t new_thread;
    pthread_create(&new_thread,NULL,read_data,obj);
    pthread_join(new_thread,(void**)&res);


    for (int i = 0; i <= 100; i++) {
        if (res[i] > 0) {
            printf("Number %d: %d count\n", i, res[i]);
        }
    }

    fclose(obj->input);
    free(res);
    shmdt(obj->add);
    shmctl(shmid, IPC_RMID, NULL);
    free(obj);
}