#include "threadPoll.h"
#include <stdio.h>

void* foo(void* arg){
    printf("The function F... ID is %d\n",*(int*)arg);
    return NULL;
}

void* goo(void* arg){
     printf("The function G... ID is %d\n",*(int*)arg);
    return NULL;
}

int main(){
    tpool pool;
    init_tpool(&pool);

    for (int i = 0; i < 12; i++)
    {
        if (i % 2)
        {
            sumbit_task(&pool, (task_t){foo, NULL});
        }else{
            sumbit_task(&pool ,(task_t){goo,NULL});
        }
    }
    while(1);
    
}