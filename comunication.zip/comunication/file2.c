#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <string.h>

int main(){
    key_t key = ftok("./file.txt",7);
    int shmid = shmget(key,4096, 0666);
    char *add  = (char*)shmat(shmid,NULL,0);

    int i = 0;
    while (add[i] != '\0')
    {   
        printf("%c ",add[i]);
        fflush(stdout);
i++;radixsort           
    }
    add[i] = '*';
}