#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <string.h>

int main(){
    key_t key = ftok("file.txt",7);
    int shmid = shmget(key , 4096 , IPC_CREAT | 0666);
    char *add  = (char*)shmat(shmid,NULL,0);

    memset(add, 0, 4096);
    
    char sm = 'a';
    int i = 0;
    for ( i = 0; i < 26; i++)
    {
        add[i] = sm++;
    }
    add[i++] = '\0';
    while (add[i] != '*');
    printf("\nTHEnk you goodBYe ! \n");
}