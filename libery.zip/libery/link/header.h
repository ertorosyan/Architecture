void saddlePoint(int matrix[][3], int row, int column);
