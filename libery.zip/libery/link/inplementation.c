#include <stdio.h>

void saddlePoint(int matrix[][3], int row, int column){
	
	int min;
	int max;
	
	for(int i = 0 ; i < row ; ++i){
		int max = matrix[0][i];
		int index = 0;
		for(int j = 0 ; j < column ; ++j){
		
			if(max  < matrix[i][j]){
				min = matrix[i][j];
				index = i;	
			}
			
		}
		int k = 0; 
		for(k = 0; k < row ; ++k){
			if(max > matrix[k][index])
				break;
			if(row == k)
				printf("%d ",matrix[i][index]);
		}
	}
}
