#include <stdio.h>
#include "header.h"

int main(){
	int row = 3;
	int column = 3;
	int matrix[][3] = 		  {{4,3,2},
					  		   {5,7,1},
							   {6,8,0}};
	
	saddlePoint(matrix,row,column);
}
