void to_uper(char* str);
void to_lower(char* str);
void decimal_to_Hex(char* arr,int number);

