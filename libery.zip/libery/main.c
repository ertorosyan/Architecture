#include <stdio.h>
#include "mylib.h"



int main(){
		
	char arr[50];
	char str[20] = "Hello World";
	to_lower(str);
	printf("%s\n",str);	
	to_uper(str);
	printf("%s\n",str);	
	decimal_to_Hex(arr,x);	
}
