#include <stdio.h>

int x = 123;
void decimal_to_Hex(char* arr , int num){
	int position = 0;
	while (num ){
		int mnacort = num % 16;
		char digit = 0;
		if(mnacort < 10)
			digit = mnacort + '0';
		else
			digit = mnacort + 'A' - 10;
	
		arr[position++] = digit;
		num /= 16;
	}
	arr[position] = '\0';
	
	printf("0x :");
	for(int i =(position-1) ; i >= 0; i--){
		printf("%c" ,arr[i]);
	}
	printf("\n");

	
}

void to_uper(char* str){
	if(str == NULL)
		return;
	while(*str != '\0'){
		if(*str >= 97 && *str <= 122)
			*str -= 32;		
		++str;
	}
}

void to_lower(char* str){
	if(str == NULL)
		return;
	while(*str != '\0'){
		if(*str >= 65 && *str <= 90)
			*str += 32;		
		++str;
	}
}
