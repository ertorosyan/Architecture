const express = require('express');
const session = require('express-session');
const path = require('path')

const app = express();
app.use(session({
    'secret': '343ji43j4n3jn4jk3n'
  }))

app.get('/ab' , (req,res) => {
    res.send("hi !");
    // res.send(req.params.theValue.toUpperCase());
    // console.log(req.headers);    
    // res.redirect('back');
    // res.json({ username: 'Flavio' })
    // res.sendStatus(200);
    // res.sendFile(path.resolve(__dirname , 'static' , 'index.html'));
})

app.get('/feature' , function(req,res){
    res.sendFile(path.resolve(__dirname , 'static' , 'feature.html'));
})

app.get('/download' , function(req,res){
    res.download(path.resolve(__dirname , 'static' , 'index.html'));
})

app.listen(4450, () => {
    console.log("Servers is started...");   
});