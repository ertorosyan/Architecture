#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <stdbool.h>
#include <sys/types.h>

typedef struct My_mutex {
    int is_lcked;
}My_mutex;

int glob = 0;


void * th11(My_mutex * obj){


            while (__sync_lock_test_and_set(&(obj->is_lcked),1)){}
    for (int i = 0; i < 1000000; i++)
    {
            int lock = glob;
            lock += 1;
            glob = lock; 
    }
            __sync_lock_release(&(obj->is_lcked));

    return NULL;
}

int main(){
    My_mutex *obj = malloc(sizeof(My_mutex));
    obj->is_lcked = 0;

    pthread_t th1,th2,th3,th4;
    pthread_create(&th1,NULL,(void*)th11,obj);
    pthread_create(&th2,NULL,(void*)th11,obj);
    pthread_create(&th3,NULL,(void*)th11,obj);
    pthread_create(&th4,NULL,(void*)th11,obj);

    pthread_join(th1,NULL);
    pthread_join(th2,NULL);
    pthread_join(th3,NULL);
    pthread_join(th4,NULL);

    printf("%d",glob);
    free(obj);
}
