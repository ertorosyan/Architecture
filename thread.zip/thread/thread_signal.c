#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>
#include <pthread.h>

sigset_t set;

void* thread_func(void* arg){
    // sleep(1);
    // sigemptyset(&set);
    // pthread_sigmask(SIG_BLOCK,&set,NULL);
    while(1);
    return NULL;
}

int main(){
    sigemptyset(&set);
    sigaddset(&set,SIGINT);
    pthread_t th1,th2;

    pthread_sigmask(SIG_BLOCK,&set,NULL);

    pthread_create(&th1,NULL,thread_func,NULL);
    pthread_create(&th2,NULL,thread_func,NULL);
    while(1);
    // pthread_exit(NULL);
    // pthread_join(th1,NULL);
}