#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <string.h>
#include<unistd.h>



int main(){
    key_t key = ftok("./file.txt",7);
    int shmid = shmget(key,4096,IPC_CREAT | 0666);
    int *add  = (int*)shmat(shmid,NULL,0);

    int cap = 10;

        if(add[cap]){
            memset(add,0,4096);
            printf("page is Clear !");
        }
    
    
}