#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <stdbool.h>
#include <sys/types.h>

int flag = 0;
int count = 0;

typedef struct {
    int n;
} ZeroEvenOdd;

ZeroEvenOdd* zeroEvenOddCreate(int n) {
    ZeroEvenOdd* obj = (ZeroEvenOdd*) malloc(sizeof(ZeroEvenOdd));
    obj->n = n;
    return obj;
}

pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t cond = PTHREAD_COND_INITIALIZER;

// You may call global function `void printNumber(int x)`
// to output "x", where x is an integer.

void zero(ZeroEvenOdd * obj) {
    pthread_mutex_lock(&mutex);
    while (count < obj->n)
    {
        while(flag != 0)
            pthread_cond_wait(&cond, &mutex);
            
        if (count % 2 && count < obj->n)
            flag = 1;
        if (count % 2 == 0 && count < obj->n)
            flag = 2;
        count++;
        dprintf(1, "0");
        // dprintf(1,"count zero = %d\n ",count);
        pthread_cond_broadcast(&cond);
    }
    pthread_mutex_unlock(&mutex);
}

void even(ZeroEvenOdd * obj) {
    pthread_mutex_lock(&mutex);
    while (count < obj->n)
    {
        while(flag != 1)
            pthread_cond_wait(&cond, &mutex);

        dprintf(1, "%d", count);
        flag = 0;
                // dprintf(1,"count even = %d\n ",count);

        pthread_cond_broadcast(&cond);
    }
    pthread_mutex_unlock(&mutex);
}

void odd(ZeroEvenOdd * obj) {
    pthread_mutex_lock(&mutex);
    while (count < obj->n)
    {
        while(flag != 2)
            pthread_cond_wait(&cond, &mutex);

        
        dprintf(1, "%d", count);
        flag = 0;
        pthread_cond_broadcast(&cond);
    }
    pthread_mutex_unlock(&mutex);
    
}


void* zeroEvenOddFree(void * arg) {
    return NULL;    
}

int main(){
    int n;
    printf("Printf Enter N : ");
    scanf("%d",&n);

    ZeroEvenOdd * obj = zeroEvenOddCreate(n);

    pthread_t th1,th2,th3;
    pthread_create(&th1,NULL,(void*)zero,(void*)obj);
    pthread_create(&th2,NULL,(void*)odd,(void*)obj);
    pthread_create(&th3,NULL,(void*)even,(void*)obj);

    pthread_join(th1,NULL);  
    pthread_join(th2,NULL);  
    pthread_join(th3,NULL);  
    pthread_cond_destroy(&cond);
    pthread_mutex_destroy(&mutex);
}