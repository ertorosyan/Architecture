#ifndef TPOOL
#define TPOOL

#include <stdio.h>
#include <pthread.h>
#include <pthread.h>
#include <stdlib.h>
#include "queue.h"

#define THREAD_COUNT 4
typedef struct tpool
{
    pthread_mutex_t mutex;
    pthread_cond_t cond;
    pthread_t threads[THREAD_COUNT];
    queue_t queue;
}tpool;

void init_tpool(tpool * pool);
void sumbit_task(tpool *,task_t);
void * thread_main(void *);

#endif //TPOOL