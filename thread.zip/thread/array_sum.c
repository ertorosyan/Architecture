#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <stdbool.h>

/*
Գրել ծրագիր, որը կստեղծի 2 thread, 1-ին thread-ի կանչած ֆունկցիան դինամիկ հիշողությունից
 կվերցնի զանգված և կլցնի զանգվածի մեջ մինչև N-ը էղած բոլոր պարզ թվերը։ 
 2-րդ thread-ը ստանալու է 1-ին thread-ում ստեղծված զանգվածը և կտպի էկրանին զանգվածի տարրերը։ 
 Ինչպես նաև կազատի դինամիկ հիշողությունից վերցրած տարածքը։
*/
typedef struct Sum
{
    int * arr;
    int size;
}Sum;

bool simple_digit(int num){
    if(num == 0)return false;
    if(num == 1)return false;
    int count = 1;
    for(int i = 2 ; i <= num ;++i ){
        if(num % i == 0)
            count++;
    }
    if(count == 2)
        return true;
    
    return false;
}

void * arr_sum(void *args){
    Sum *obj = (Sum*)args;
    int* res = (int*)calloc(obj->size,sizeof(int));

    int j = 0;
    int count = 0;
    for (int i = 0; i < obj->size; i++){
        if(simple_digit(obj->arr[i]) == 1){
            res[j++] = obj->arr[i];
            count++;
        }
    }
    res = realloc(res,sizeof(int) * count);
    free(obj->arr);
    obj->arr = res;
    obj->size = count;
    return (void*)res; 
}

void * print_arr(void * args){

    Sum * obj = (Sum*)args;
    for (int i = 0; i < obj->size; i++)
        printf("%d ",obj->arr[i]);
    printf("\n");
    free(obj->arr);
    return NULL;
}


int main(){
    int n;
    printf("Enter N : ");
    scanf("%d",&n);

    Sum obj;
    obj.size = n;
    obj.arr = malloc(obj.size *  sizeof(int));
    for(int i = 0 ; i < obj.size ; i++)
        obj.arr[i] = i;

    int * res ;
    pthread_t thread_1;
    pthread_create(&thread_1,NULL,arr_sum,(void *)&obj);
    pthread_join(thread_1,(void**)&res);
    
    pthread_t thread_2;
    pthread_create(&thread_2,NULL,print_arr,(void *)&obj);
    pthread_join(thread_2,NULL);

    // for (int i = 0; i < 5; i++)
    // {
    //     printf("%d ",res[i]);
    // }
    

    // free(res);
}