#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include <stdbool.h>
#include <sys/types.h>
/*
4. Գրել ծրագիր, որը կստեղծի thread: Thread-ը իր հերթին կկանչի ֆունկցիա,
 ֆունկցիան որպես արգումենտ կստանա  student struct-երի զանգված,
  և կվերադարձնի ամենաբարձր գնահատականը ստացած ուսանողնի տվյալները։
*/
int size_arr;

typedef struct Student{
    char *name;
    int grade;
}Student;


void * max_grat(void* args){
    Student *arr = (Student *)args;
    int *max_grade = (int *)malloc(sizeof(int));
    *max_grade = 0;
    for (int i = 0; i < size_arr; i++)
    {
        if(arr[i].grade > *max_grade)
            *max_grade = arr[i].grade;
    }

    return (void *)max_grade;
}

int main(){
    printf("Enter array size : ");
    scanf("%d",&size_arr);

    Student *arr = malloc(size_arr * sizeof(Student));
    
    for (int i = 0; i < size_arr; i++)
    {   
        printf("Enter Student Name : ");
        char tmp[20];
        scanf("%s",tmp);
        arr[i].name = strdup(tmp);
        printf("Enter Student grade : ");
        int grade;
        scanf("%d",&grade);
        arr[i].grade = grade;
        printf("\n");
    }

    int * max_gread;
    pthread_t thread = 0;
    pthread_create(&thread,NULL,max_grat,(void*)arr);
    pthread_join(thread,(void**)&max_gread);

    printf("Max grade = %d\n",*max_gread);

    free(max_gread);
    for (int i = 0; i < size_arr; ++ i)
        free(arr[i].name);
}