#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <string.h>
#include<unistd.h>


int main(){
    key_t key = ftok("file.txt",7);
    int shmid = shmget(key,4096,IPC_CREAT | 0666);
    int *add  = (int*)shmat(shmid,NULL,0);
    
    int sm  = 10 ;
    int i = 0;
    for ( i = 0; i < 26; i++)
    {   
        // sleep(1);
        add[i] = sm;
        printf("%d ",add[i]);
    }
    
}