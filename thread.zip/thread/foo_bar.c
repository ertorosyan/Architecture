#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <stdbool.h>
#include <sys/types.h>

typedef struct {
    int n;
} FooBar;

int flag = 0;  //Flag
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER ;
pthread_cond_t cond  = PTHREAD_COND_INITIALIZER;

void printFoo(){
    printf("foo");
}

void printBar(){
    printf("bar");
}


FooBar* fooBarCreate(int n) {
    FooBar* obj = (FooBar*) malloc(sizeof(FooBar));
    obj->n = n;
    return obj;
}

void  foo(FooBar* argc) {
    // int * n = (int*)argc;
    for (int i = 0; i < argc->n; i++) {
         pthread_mutex_lock(&mutex);
            // printFoo() outputs "foo". Do not change or remove this line.
            printFoo();
            flag = 1;
            pthread_cond_signal(&cond);
        pthread_mutex_unlock(&mutex);

        pthread_mutex_lock(&mutex);
        if(flag != 0) {
            pthread_cond_wait(&cond, &mutex);
        }
        pthread_mutex_unlock(&mutex);
        // while(flag == 1);
    }
    return ;
}

void* bar(void* argc) {
   int * n = (int*)argc;

    for (int i = 0; i < *n; i++) {
        pthread_mutex_lock(&mutex);
        if(flag == 0)
        {
            pthread_cond_wait(&cond,&mutex);
        }
            // printBar() outputs "bar". Do not change or remove this line.
        printBar();
        flag = 0;
        pthread_cond_signal(&cond);
        pthread_mutex_unlock(&mutex);
    }
    return NULL;
}


int main(){
    fooBarCreate(3);
    pthread_mutex_init(&mutex,NULL);
    pthread_cond_init(&cond,NULL);

    pthread_t th1,th2;
    int n;
    scanf("%d",&n);
    
    pthread_create(&th1,NULL,(void*(*)(void*))foo,&n);
    pthread_create(&th2,NULL,bar,&n);

    pthread_join(th1,NULL);
    pthread_join(th2,NULL);
    printf("\n");

    pthread_mutex_destroy(&mutex);
    pthread_cond_destroy(&cond);
}