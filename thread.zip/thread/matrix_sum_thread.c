#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <stdbool.h>
#include <sys/types.h>

int sum = 0;


pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;

void * matrix_sum(void *arg){
    int i = 0;
    int j = 0;
    int ** matrix = (int**)arg;

    int local_sum = 0;

    for ( i = 0; i < 3; i++) {
        for ( j = 0; j < 3; j++){
            pthread_mutex_lock(&lock);
            sum += matrix[i][j];
            pthread_mutex_unlock(&lock);
        }
    }
        
    return NULL;
}


int main(){
    int col = 3;

    int ** matrix = (int **)malloc(col * sizeof(int*));
    for(int i = 0; i < col ; ++i)
        matrix[i] = (int *)malloc(col * sizeof(int)); 

    for (int i = 0; i < col; i++)
        for (int j = 0; j < col; j++)
            matrix[i][j] = 1;

    int ** matrix2 = (int **)malloc(col * sizeof(int*));
    for(int i = 0; i < col ; ++i)
        matrix2[i] = (int*)malloc(col * sizeof(int)); 
    
    for (int i = 0; i < col; i++)
        for (int j = 0; j < col; j++)
            matrix2[i][j] = 2;
        
    

    pthread_t th1,th2;
    pthread_create(&th1,NULL,matrix_sum,(void**)matrix);
    pthread_create(&th2,NULL,matrix_sum,(void**)matrix2);

    pthread_join(th1,NULL);
    pthread_join(th2,NULL);


    printf("SUM = %d\n",sum);
    for (int i = 0; i < col; i++)
        free(matrix[i]);
    free(matrix);

    for (int i = 0; i < col; i++)
        free(matrix2[i]);
    free(matrix2);
}