/*
Գրել ծրագիր, որի կատարման արդյունքում կստեղծվի child process,
 child process-ը ստանում է signal եթե signal-ը լինի segmentation fault
  կստեղծվի 2 thread, 1-ին thread-ը կկանչի ֆունկցիա և ֆունկցիայի կատարման արդյունքում 
  դինամիկ հիշողությունից տարածք կվերցնի ստեղծելով երկչափ դինամիկ զանգված։ 
  2-րդ thread-ի կանչած ֆունկցիան free() կանի դինամիի հիշողությունից վերցրած զանգվածը։
*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <stdbool.h>
#include <sys/types.h>

void * make_matrix(void *args){
    int ** matrix = (int**)args;
    matrix = malloc(5 * sizeof(int*));
    for (int i = 0; i < 5; i++)
        matrix[i] = malloc(5 * sizeof(int));
    printf("Make matrix\n");
    return (void*)matrix;
}

void * free_matrix(void *args){
    int** matrix = (int**)args;
    for (int i = 0; i < 5; i++)
        free(matrix[i]);
    free(matrix);
    printf("Matrix is a free\n");
    return NULL;
}

void sigsegv_hendler(int signum){
    pthread_t thread_1;
    int **matrix;
    pthread_create(&thread_1,NULL,make_matrix,(void**)matrix);
    pthread_join(thread_1,(void**)&matrix);

    pthread_t thread_2;
    pthread_create(&thread_2,NULL,free_matrix,(void**)matrix);
    pthread_join(thread_2,NULL);
    exit(EXIT_SUCCESS);
}

int main(){
    pid_t proc = fork();
    if(proc < 0){
        perror(" Fork ! ");
        exit(EXIT_FAILURE);
    }else if(proc == 0){
        if(signal(SIGSEGV,sigsegv_hendler) == SIG_ERR){
            perror("signal !!");
            return EXIT_FAILURE;
        }

        printf("hello I'm CHild ooo ~~ SigSegv !!! \n");
        int *p = NULL;
        *p = 42;
    }else{
        wait(NULL);
    }
}