#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <sys/mman.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include <signal.h>
#define PTHREAD_COUNT 2
#define MAX_LINE 500


pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
typedef struct Info
{
    FILE * input;
    char* add;
    int word_count;
    char *most_repeth_word;
    sigset_t set;
    pthread_t th2;
}Info;

void file_open(Info* obj){

    obj->input = fopen("data.txt","w+");
    if(obj->input == NULL){
        perror("File open !");
        exit(0);
    }
    char * buf = "   asa oves du asa ov ape asa a  ";
    if(fwrite(buf,strlen(buf),1,obj->input) != 1){
        perror("fwrite !\n");
        exit(0);
    }
}

void * read_string_word_count(void* arg){
    Info* obj = (Info*)arg;
    char buf[MAX_LINE];

    while (fgets(buf,sizeof(buf),obj->input))
    {
        strcat(obj->add,buf);
    }

    int i= 0;
    int word_count = 0;
    int symbol = 0;
    while (obj->add[i]) {
        if (obj->add[i] != ' ') {
            symbol++;
        } else if (symbol > 0) {
            word_count++;
            symbol = 0; 
        }
        i++;
    }
    obj->word_count = word_count;

    pthread_kill(obj->th2,SIGUSR1);
    return NULL;
}

void * most_repeth_word(void* arg){

    Info* obj = (Info*)arg;
    int sig;
    sigwait(&obj->set,&sig);
    char * max_word = malloc(sizeof(char) * strlen(obj->add));
    int i = 0;
    int j = 0;

    while (obj->add[i])
    {
        if (obj->add[i] != ' '){
            max_word[j++] = obj->add[i++];
        }else if(obj->add[i] == ' ' && j > 0){
            j = 0;
            // ??????????????????????????
            //veradarcni amenashat handipox bar-y shared-memory -ic  !!!
        }
        
        
        
    }
    

    return NULL;
}

int main(){
    Info* obj = malloc(sizeof(Info));

    key_t key = ftok("file.txt",7);
    if(key == -1){
        perror("Ftok !\n");
        exit(0);
    }
    int shmid = shmget(key,4096,IPC_CREAT | 0666);
    obj->add = shmat(shmid,NULL,0);
    if(obj->add == NULL){
        perror("shmat !\n");
        exit(0);
    }

    sigemptyset(&obj->set);
    printf("!!!!!!\n");
    sigaddset(&obj->set,SIGUSR1);

    pthread_sigmask(SIG_BLOCK,&obj->set,NULL);

    file_open(obj);
    rewind(obj->input);

    pthread_t th1;
    pthread_create(&th1,NULL,read_string_word_count,obj);
    pthread_create(&obj->th2,NULL,most_repeth_word,obj);

    pthread_join(th1,NULL);
    pthread_join(obj->th2,NULL);

    free(obj);
    fclose(obj->input);
    shmdt(obj->add);
    shmctl(shmid, IPC_RMID, NULL);
}