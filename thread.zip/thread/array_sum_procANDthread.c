#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <stdbool.h>
#include <sys/types.h>


/*
3. Գրել ծրագիր, որի կատարման արդյունքում child process-ը կստեղծի thread,
 որը իր հերթին կկանչի ֆունկցիա։ Ֆունկցիան տպելու է էկրանին զանգվածի տարրեի գումարը։
  Եթե փոխանցած զանգվածի չափը լինի 0, 
պետք է հետ վերադառնա Child process և տպի էկրանին համապատասխան հաղորդագրություն։
*/
typedef struct Sum {
    int size;
    int * arr;
    int ret;
}Sum;


void* sum_arr_print(void *args){
    Sum * res = (Sum *)args;
    res->ret = 0;
    if(res->size == 0){
        res->ret = -1;
        return (void *)res;
    }

    res->arr = malloc(res->size * sizeof(int));
    for (int i = 0; i < res->size; i++)
        res->arr[i] = i;

    int sum = 0;
    for (int i = 0; i < res->size; i++)
        sum += res->arr[i]; 

    printf("Sum of array = %d\n",sum);
    return (void *)res;
}

int main(){

    pid_t proc= fork();
        if(proc < 0){
            perror("Fork !");
            exit(EXIT_FAILURE);
        }
        else if(proc == 0){
            Sum obj;
            printf("Enter array size : ");
            scanf("%d",&obj.size);
            
            pthread_t thread;
            pthread_create(&thread,NULL,sum_arr_print,(void*)&obj);
            pthread_join(thread,(void**)&obj);
            if(obj.ret == -1){
                printf("Size array = 0 !!!\n");
            }
        }else{
            wait(NULL);
        }
}
