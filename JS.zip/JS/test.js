// function test(){

//     let arr = [1,2,3,4];
//     if (sumEvenNumbers(arr) === 6) {
//         console.log("Test #1 is cussessfull )");
//     } else {
//         console.log("Test #1 False");
//     }
    
//     arr = [];
//     if (sumEvenNumbers(arr) === 0) {
//         console.log("Test #2 is cussessfull )");
//     } else {
//         console.log("Test #2 False");
//     }

//     arr = ["hellow"];
//     if (sumEvenNumbers(arr) === 0) {
//         console.log("Test #3 is cussessfull )");
//     } else {
//         console.log("Test #3 False");
//     }

//     arr = [1 , 'a' , 2 , 'c' ];
//     if (sumEvenNumbers(arr) === 0) {
//         console.log("Test #3 is cussessfull )");
//     } else {
//         console.log("Test #3 False");
//     }
        
// }

// function sumEvenNumbers(arr){

//     if (arr == null) {
//         return 0;
//     } else if(typeof(arr[0]) == 'string') {
//         return 0;
//     }

//     for (let i = 0; i < arr.length; i++) {
//         if (typeof(arr[i]) != 'number') {
//             return 0;
//         }
//     }

//     let sum = 0;
//     for (let i = 0; i < arr.length; ++i) {
//         if (arr[i] % 2 == 0) {
//             sum += arr[i];
//         };
//     }

//     return sum;
// }

// test();


// 'use strict'

// const Newdata = (person,adddata = Date()) => ({
//     ...person,
//     Data: adddata,
// })

// const firsPerson = {
//     id: 1,
//     name: "Er",
// }

// const newpost = Newdata(firsPerson);

// console.table(newpost);

const test = () => {
    throw new Error('Some error');
}
try {
    test()
}catch (error) {
    // console.error(error);
    console.log(error.message)
}

console.log("asfsaf");