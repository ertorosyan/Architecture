#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define BUF_SIZE 1024
#define CPU_COUNT 8

struct user {
    char name[50];
    int fd; 
} typedef User;


typedef struct info{
    FILE * history;
    User arr[8];   
}Info;

Info obj;


void check(const char* msg){
    perror(msg);
    exit(1);
}

void join_function(const char *msg , int index_client){
    char *name = strtok((char*)msg, " ");
    //name --> JOIN
    while (name != NULL){
        if(strcmp(name,"JOIN") != 0)
            break;
        name = strtok(NULL," ");
    }
    printf("%s\n",name);
    if (name) {

        name[strlen(name) + 1] = '\n';
        char new_msg[20];
        strcpy(new_msg,"Welcome ");
        strcat(new_msg,name);
        strcpy((obj.arr[index_client].name), name);

        for (int i = 0; i < CPU_COUNT; i++)
        {
            if(obj.arr[i].fd != 0 && i != index_client){
                int W_byte = write(obj.arr[i].fd ,new_msg , strlen(new_msg) + 1 );
                if(W_byte <= 0){
                    perror("Don't write clients msg !");
                    return;
                } 
            }    
        }
        
    }
}

int word_count(char * str) {
    int count = 0;
    for (int i = 0; str[i]; ++ i) {
        while(str[i] && str[i] == ' ')
            i++;
        count ++;
        while (str[i] && str[i] != ' ')
            i++;
    }
    return count;
}

void direct_function(char *msg , int index_client){

    char *temp = strdup(msg);
    int wordc = word_count(msg);
    char **arr = (char ** ) malloc(sizeof(char *) * (wordc + 1));
    arr[wordc] = NULL;
    
    char *tmp = strtok(msg, " ");
    arr[0] = strdup(tmp);

    for (int i = 1; i < wordc; ++ i)
        arr[i] = strdup(strtok(NULL, " "));

    int idx;
    for (idx = 0; idx < 8; ++ idx) {
        if (!strcmp(obj.arr[idx].name, arr[0]))
            break;
    }
    if (idx == 8)
    {
        printf("Name not found\n");
        for (int i = 0; arr[i]; ++ i)
            free(arr[i]);
        free(arr);
        return ;
    }


    dprintf(obj.arr[idx].fd, "%s\n", temp + (strlen(arr[0]) + 1));

    for (int i = 0; arr[i]; ++ i)
        free(arr[i]);
    free(arr);
    free(temp);
}

void msg_function(char *msg , int index_client){
    int i = 0;
    while (msg && msg[i] && msg[i] == ' ')
        i++;

    msg += i;
    int wordc = word_count(msg);


      char **arr = (char ** ) malloc(sizeof(char *) * (wordc + 1));
    arr[wordc] = NULL;
    
    char *tmp = strtok(msg, " ");
    arr[0] = strdup(tmp);

    for (int i = 1; i < wordc; ++ i){
        arr[i] = strdup(strtok(NULL, " "));
    }
    char sendMsg[BUF_SIZE] = {0};
    for(int i = 1;i < wordc;i++){
        strcat(sendMsg,arr[i]);
        strcat(sendMsg," ");
    }

    char userName[50] ={0};
    if(arr[0][0] == '@'){
        for(int i = 1; i < strlen(arr[0]);i++ ){
            userName[i -1] = arr[0][i]; 
        }
        for (int idx = 0; idx < 8; ++ idx) {
        if (!strcmp(obj.arr[idx].name, userName)){
            char new_msg[200] = {0};
            printf("%s\n",obj.arr[index_client].name);
            printf("index = %d\n",index_client);
            printf("%s\n",userName);
            sprintf(new_msg,"From %s to %s MSG: %s",obj.arr[index_client].name, userName,sendMsg);
            for (int i = 0; i < CPU_COUNT; i++)
            {
                if(obj.arr[i].fd != 0 && i != index_client){
                    int W_byte = write(obj.arr[i].fd ,new_msg , strlen(new_msg) + 1 );
                    if(W_byte <= 0){
                        perror("Don't write clients msg !");
                        return;
                    } 
                }    
            }
            break;
        }
    }
    }
    else{
        strcpy(sendMsg,msg);
        for (int i = 0; i < CPU_COUNT; i++){
                if(obj.arr[i].fd != 0 && i != index_client){
                    int W_byte = write(obj.arr[i].fd ,sendMsg , strlen(sendMsg) + 1 );
                    if(W_byte <= 0){
                        perror("Don't write clients msg !");
                        return;
                    } 
                }    
    }
   

    }

    // save to hystory.txt
    obj.history = fopen("history.txt","a");
    fprintf(obj.history , "%s\n" , sendMsg);
    fflush(obj.history);


   
     
}

void history_function(int index) {
    char buf[BUF_SIZE];

    if (index < 0) {
        perror("Invalid index\n");
        return;
    }
    fclose(obj.history);
    obj.history = fopen("history.txt", "r+");
    while (fgets(buf, BUF_SIZE, obj.history) != NULL) {
        int W_byte = write(obj.arr[index].fd, buf, strlen(buf));
        if (W_byte < 0) {
            perror("Error writing to client");
            return;
        }
        fflush(obj.history);
        memset(buf, 0, sizeof(buf));
    }
    rewind(obj.history);
}


void* handle_client(void * arg){
    int index = *(int*)arg;
    char buf[BUF_SIZE];

    while (1)
    {
        memset(buf, 0 , BUF_SIZE);
        int Rbyte = read(obj.arr[index].fd, buf, BUF_SIZE);
        if (Rbyte <= 0){
            printf("Don't read from client !!!!!!!\n");
            return NULL;
        }
        
        char *cpy = strdup(buf);
        char *tmp = strtok(cpy, " ");
        printf("tmp = %s\n",tmp);
        if(!strcmp(tmp,"JOIN")){
            join_function(buf, index);
        }else if(!strcmp(tmp,"DIRECT")){
            direct_function(buf + strlen(tmp) , index);
        }else if(!strcmp(tmp,"MSG")){
            msg_function(buf + strlen(tmp) , index);
        }else if(!strcmp(tmp,"HISTORY")){
            history_function(index);
        }else{
            int W_byte = write(obj.arr[index].fd ,"Indalid command !\n" , strlen("Indalid command !"));
            if(W_byte <= 0){
                perror("Don't write clients msg !");
            } 
        }
        free(cpy);
    }
    
    return NULL;
}




int indexa = -1;

int main(int argc, char* argv[]){
    
    if(argc < 2){
        perror("Invalid argument !");
        exit(1);
    }
    obj.history = fopen("history.txt","r+");

    int server = socket(AF_INET , SOCK_STREAM , 0);
    if(server < 0){
        check("socket()");
    }

    int port  = atoi(argv[1]);
    struct sockaddr_in server_add;
    memset(&server_add , 0 , sizeof(server_add));
    server_add.sin_family = AF_INET;
    server_add.sin_port = htons(port);
    server_add.sin_addr.s_addr = INADDR_ANY;
    socklen_t size = sizeof(server_add);

    int opt = 1;
    setsockopt(server, SOL_SOCKET, SO_REUSEPORT, &opt, sizeof(opt));

    if(bind(server , (struct sockaddr *)&server_add ,size) < 0 ){
        close(server);
        check("bind() !");
    }

    if(listen(server, CPU_COUNT) < 0){
        close(server);
        check("listen() !");
    }

    printf("Server started...\n");
    pthread_t thread_clients[CPU_COUNT];

    while (1){
        struct sockaddr_in client;
        memset(&client , 0 ,sizeof(client));
        socklen_t size = sizeof(client);

        int newsocet_fd = accept(server,(struct sockaddr *)&client ,&size);
        if(newsocet_fd < 0){
            printf("Client don't connect !");
        }
        indexa++;

        obj.arr[indexa].fd = newsocet_fd; // add accept_fd in array ''clients''
        if(pthread_create(&thread_clients[indexa] , NULL , handle_client , (void*)&indexa ) < 0){
            printf("dont create thread !!!!");
            break;
        }
    }

    for (int i = 0; i < CPU_COUNT; i++){
        pthread_join(thread_clients[indexa],NULL);
    }

    close(server);
}