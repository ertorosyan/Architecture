#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define BUF_SIZE 1024
char  check_cmds[10000] = {0};


void panic(const char* msg) {
    perror(msg);
    exit(1);
}

void maneu(){
    printf("Register -> JOIN <username>\n");
    printf("SEND message -> MSG <message>\n");
    printf("PRIVATE MSG -> DIRECT <username> <message>\n");
    printf("Send message -> MSG <message>\n");
}

void* read_handle(void* fd) {
    int client_fd = *(int*)fd;
    char buf[BUF_SIZE];
    while (1) {
        memset(buf, 0, BUF_SIZE);
        int Rbyte = read(client_fd, buf, BUF_SIZE);
        if (Rbyte <= 0) {
            if (Rbyte == 0) {
                printf("Server disconnected\n");
            } else {
                printf("Error reading from server\n");
            }
            close(client_fd);
            exit(0);
        }
        buf[Rbyte] = '\0';
        dprintf(1, "%s\n", buf);
    }
    return NULL;
}

void* write_handle(void* fd) {
    int client_fd = *(int*)fd;
    char buf[BUF_SIZE];

    int Wbyte = write(client_fd, check_cmds, strlen(check_cmds));
    if (Wbyte <= 0) {
        printf("Error writing to server\n");
        close(client_fd);
        exit(0);
    }
    while (1) {
        memset(buf, 0, BUF_SIZE);
        maneu();
        printf("::: ");
        fgets(buf, BUF_SIZE, stdin);
        buf[strcspn(buf, "\n")] = '\0'; // Remove newline character

        int Wbyte = write(client_fd, buf, strlen(buf));
        if (Wbyte <= 0) {
            printf("Error writing to server\n");
            close(client_fd);
            exit(0);
        }
    }
    return NULL;
}




int main(int arg, char * argv[]){
    int client = socket(AF_INET , SOCK_STREAM , 0);
    if(client < 0){
        panic("socket() !");
    }
    maneu();
    int port  = atoi(argv[2]);
    struct sockaddr_in client_add;

    memset(&client_add , 0 , sizeof(client_add));
    client_add.sin_family = AF_INET;
    client_add.sin_port = htons(port);
    client_add.sin_addr.s_addr = inet_addr(argv[1]);
    socklen_t size = sizeof(client_add);

    fgets(check_cmds,sizeof(check_cmds), stdin);
    check_cmds[strcspn(check_cmds, "\n")] = '\0'; // Remove newline character

    if (!strncmp(check_cmds,"JOIN", strlen("JOIN")) && check_cmds[strlen("JOIN")] == ' '){
        if (connect(client,(struct sockaddr*)&client_add , size) < 0){
            close(client);
            panic("connect() !");
        }

        pthread_t read_thread, write_thread;
        if (pthread_create(&read_thread, NULL, read_handle, (void*)&client) < 0) {
            close(client);
            panic("pthread_create_read !");
        }

        if (pthread_create(&write_thread, NULL, write_handle, (void*)&client) < 0) {
            close(client);
            panic("pthread_create_write");
        }

        pthread_join(read_thread, NULL);
        pthread_join(write_thread, NULL);
    
    }else{
        printf("Client don't connect\n");
    }
    

    close(client);
}