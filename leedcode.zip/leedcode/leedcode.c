#include <stdio.h>
#include <limits.h>



///veradarcni stringi meji tvery tveric araj kara lini menak ' ' ete mec lini int-i chapic veradarcni max_int 
// hakarak dempqum min_int , datark linrlu depqum -1, ete tivy skski - ov tpi -(number)

int myAtoi(char* arr) {
    int i = 0;
    int res = 0;
	int sign = 0;
      			
		if(arr[i] == '\0')
			return -1;
      	while(arr[i] != '\0'){
					
				while(arr[i] == ' '){ ++i; }

				if(arr[i] == '+'){
					sign = 1;
					++i;
				}
				
				if(arr[i] == '-') {
					sign = -1;
					++i;
				}
				 
				if(arr[i] < '0' || arr[i] > '9'){ break; }
	
				res = res * 10 + arr[i] - '0'; 
			 	i++;
	  	}
			
			if((res * sign) > INT_MAX) { 
				return INT_MAX;
			}else if((res * sign) < INT_MIN){
				 return INT_MIN;
			} else
				 return res * sign;
		
		
}
  int main(void)
   {
	char arr[40] = " 23efs";
	int x = myAtoi(arr);	
	printf("%d",x);
   }
