#include <stdio.h>

int count(char* str,int index,int sum){
	if(str == NULL)
		return -1;
	if(str[index] == '\0')
		return sum;
	return  count(str,index+1 ,sum + 1);
}



int main(){
	char str[20];
	scanf("%s",str);
	int sum = 0;
	printf("Count = %d\n",count(str,0,sum));
}
