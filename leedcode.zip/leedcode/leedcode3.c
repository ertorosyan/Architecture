#include <stdio.h>


// unenq zangvac u k 
// k hat element zangvaci skzvic bervuma skizb

int* new(int *nums , int* new_nums , int size, int k){


	if(k > size) {printf("Zangvaci chapic shat tvov uzues shur tas"); return new_nums;};
	int i = 0 , j = 0;

	for( i = size-1 , j = 0 ; k > 0 ; --i , ++j , --k){
		new_nums[j] = nums[i] ;
	}

	i = 0;

	while ( j < size ){
		new_nums[j] = nums[i];
		++j;
		++i;
	}
	
	return new_nums;
}




int main(){
	
	int nums[] = {1,2,3,4,5,6,7};
	int size = sizeof(nums)/sizeof(int);
	int new_nums[size];
	int k = 4;

	new(nums,new_nums,size,k);

	for(int i = 0 ; i < size ; ++i){
		printf("%d ", new_nums[i]);
	}

}
