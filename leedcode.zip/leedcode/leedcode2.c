#include <stdio.h>


// tvaca string , vori mej grvaca barer u iraric arandznanum en ' '-ov
//  gtnel verin bari erkarrutyuny 


int length(char* str){
	
	int i = 0;
	int count = 0;
	while(str[i] != '\0')   //gtnum em stringi erkarutyuny
		i++;

	while(str[i-1] == ' ')
		i--;
				
	for(int j = i-1; str[j] != ' ' &&  j > -1 ; j-- )  //stringi verjic galisem minche ' '
		++count;
	
	return count;
}




int main(){
	char str[30] = "a";
	printf("\nVerjin bary uni %d tar\n\n" , length(str));
}
