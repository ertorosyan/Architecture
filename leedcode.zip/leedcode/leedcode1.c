#include <stdio.h>


void swap(int *x , int *y ){
	int tmp = *x;
	*x = *y;
	*y = tmp;
}

int* new(int* arr, int size , int* new_arr){

	for(int i = 0 ; i < size ; ++i ){
		new_arr[i] = arr[i] * arr[i];
	}
			
	for(int i = 1 ; i < size ; ++i ){
		for(int j = 0 ; j < size - 1 - i ; ++j){
			if(new_arr[j] > new_arr[j+1]){
				swap(&new_arr[j],&new_arr[j+1]);
			}
		}
	}
	return new_arr;
}


int main(){
	
	int arr[] = {-4,-1,0,3,10};
	int size = sizeof(arr)/sizeof(int);
	int new_arr[size];


	new(arr,size,new_arr);


	printf("Old Array \n\n");

	for(int i = 0 ; i < size ; ++i ){
		printf(" %d ", arr[i]);
	}

	printf("\n\n New Array (element^2) and sort array\n\n");

	for(int i = 0 ; i < size ; ++i ){
		printf(" %d ", new_arr[i]);
	}

}
